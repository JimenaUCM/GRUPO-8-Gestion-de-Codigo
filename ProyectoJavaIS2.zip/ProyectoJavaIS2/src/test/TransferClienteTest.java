package test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrowsExactly;

import org.junit.jupiter.api.Test;

import negocio.TransferCliente;
import negocio.TransferUsuario;

class TransferClienteTest {
	@Test
	void basic_behaviour() {
		String nombre = "Nombre";
		String apellidos = "Apellidos";
		String dni = "12345678A";
		String password = "1234";
		int saldo = 100;

		TransferUsuario usuario = new TransferUsuario(nombre, apellidos, dni, password);
		TransferCliente cliente1 = new TransferCliente(nombre, apellidos, dni, password, saldo);
		TransferCliente cliente2 = new TransferCliente(usuario, saldo);

		assertEquals(cliente1, cliente2,
				"El constructor mediante usuario y mediante datos no dan el mismo resultado con mismo datos");
		assertEquals(cliente1.getNombre(), nombre, "TransferUsuario.getNombre() da un valor no esperado");
		assertEquals(cliente1.getApellidos(), apellidos, "TransferUsuario.getApellidos() da un valor no esperado");
		assertEquals(cliente1.getDni(), dni, "TransferUsuario.getDni() da un valor no esperado");
		assertEquals(cliente1.getPassword(), password, "TransferUsuario.getPassword() da un valor no esperado");
		assertEquals(cliente1.getSaldo(), saldo, "TransferUsuario.getApellidos() da un valor no esperado");

		String nombreNuevo = "NombreN";
		cliente1.setNombre(nombreNuevo);
		assertEquals(cliente1.getNombre(), nombreNuevo, "TransferUsuario.setNombre() da un valor no esperado");

		String apellidosNuevo = "ApellidosN";
		cliente1.setApellidos(apellidosNuevo);
		assertEquals(cliente1.getApellidos(), apellidosNuevo, "TransferUsuario.setApellidos() da un valor no esperado");

		String dniNuevo = "12345678N";
		cliente1.setDni(dniNuevo);
		assertEquals(cliente1.getDni(), dniNuevo, "TransferUsuario.setDni() da un valor no esperado");

		String passwordNuevo = "1234N";
		cliente1.setPassword(passwordNuevo);
		assertEquals(cliente1.getPassword(), passwordNuevo, "TransferUsuario.setPassword() da un valor no esperado");

		int saldoNuevo = 1000;
		cliente1.setSaldo(saldoNuevo);
		assertEquals(cliente1.getSaldo(), saldoNuevo, "TransferUsuario.setApellidos() da un valor no esperado");
	}

	@Test
	void errors_handling() {
		String nombre = "Nombre";
		String apellidos = "Apellidos";
		String dni = "12345678A";
		String password = "1234";
		int saldo = 100;

		// nombre no puede estar vacio
		assertThrowsExactly(IllegalArgumentException.class,
				() -> new TransferCliente("", apellidos, dni, password, saldo), " casilla vacia");

		// apellidos no puede estar vacio
		assertThrowsExactly(IllegalArgumentException.class, () -> new TransferCliente(nombre, "", dni, password, saldo),
				" casilla vacia");

		// el dni tiene que tener formato valido
		assertThrowsExactly(IllegalArgumentException.class,
				() -> new TransferCliente(nombre, apellidos, "123", password, saldo), "DNI inválido, tamaño inválido");
		assertThrowsExactly(IllegalArgumentException.class,
				() -> new TransferCliente(nombre, apellidos, "123456789", password, saldo),
				"DNI inválido, ultimo valor letra");
		assertThrowsExactly(IllegalArgumentException.class,
				() -> new TransferCliente(nombre, apellidos, "123A45678", password, saldo),
				"DNI inválido, los primeros no son numeros");

		// saldo no puede ser negativo
		assertThrowsExactly(IllegalArgumentException.class,
				() -> new TransferCliente(nombre, apellidos, dni, "", saldo), " casilla vacia");

		// saldo no puede ser negativo
		assertThrowsExactly(IllegalArgumentException.class,
				() -> new TransferCliente(nombre, apellidos, dni, password, -1), "Saldo no puede ser negativo");

	}
}
