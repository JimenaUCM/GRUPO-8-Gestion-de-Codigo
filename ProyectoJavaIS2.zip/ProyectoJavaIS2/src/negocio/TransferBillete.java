package negocio;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import util.Fecha;

public class TransferBillete {
	private int _numeroAsiento;
	private int _precio;
	private int _valoracion;
	private boolean _estaDisponible;
	private TransferTren _tren;
	private TransferCliente _cliente;
	private Set<TransferServicio> _servicios;
	private Fecha _fecha;

	public TransferBillete(TransferTren tren, int numeroAsiento, int precio, int valoracion, boolean disponible,
			TransferCliente cliente, Fecha fecha) {
		validate(numeroAsiento);
		if (valoracion < 0 || valoracion > 5) {
			throw new IllegalArgumentException(valoracion + " la valoracion es inválido , tiene que ser entre 0 a 5");
		}
		this._precio = precio;
		this._tren = tren;
		this._numeroAsiento = numeroAsiento;
		this._valoracion = valoracion;
		this._estaDisponible = disponible;
		this._servicios = new HashSet<TransferServicio>();
		this._cliente = cliente;
		this._fecha = fecha;
	}

	private void validate(int i) {
		if (i <= 0) {
			throw new IllegalArgumentException(i + " es negativo");
		}
	}

	public TransferBillete(TransferTren tren, int numeroAsiento, int precio, TransferCliente cliente, Fecha fecha) {
		this._tren = tren;
		this._numeroAsiento = numeroAsiento;
		this._precio = precio;
		this._valoracion = -1;
		this._estaDisponible = true;
		this._cliente = null;
		this._fecha = fecha;
	}

	public TransferBillete(TransferBillete billete) {
		this(billete._tren, billete._numeroAsiento, billete._precio, billete._valoracion, billete._estaDisponible,
				billete._cliente, billete._fecha);
	}

	public int getNumeroAsiento() {
		return _numeroAsiento;
	}

	public void setNumeroAsiento(int numeroAsiento) {
		this._numeroAsiento = numeroAsiento;
	}

	public int getPrecio() {
		return _precio;
	}

	public void setPrecio(int precio) {
		this._precio = precio;
	}

	public int getValoracion() {
		return _valoracion;
	}

	public void setValoracion(int valoracion) {
		this._valoracion = valoracion;
	}

	public boolean isEstaDisponible() {
		return _estaDisponible;
	}

	public void setEstaDisponible(boolean estaDisponible) {
		this._estaDisponible = estaDisponible;
	}

	public TransferTren getTren() {
		return _tren;
	}

	public void setTren(TransferTren tren) {
		this._tren = tren;
	}

	public Collection<TransferServicio> getServicios() {
		return _servicios;
	}

	public Iterator<TransferServicio> getServicio() {
		return _servicios.iterator();
	}

	public void addServicio(TransferServicio servicios) {
		this._servicios.add(servicios);
	}

	public Fecha getFecha() {
		return _fecha;
	}

	public TransferCliente getCliente() {
		return _cliente;
	}

	public void setCliente(TransferCliente cliente) {
		_cliente = cliente;
	}
}
