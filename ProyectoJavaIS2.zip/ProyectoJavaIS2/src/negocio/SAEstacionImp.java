package negocio;

import java.util.Collection;

import integracion.DAOEstacion;
import integracion.FactoriaDAOBDImp;

public class SAEstacionImp implements SAEstacion {

	DAOEstacion _DAO_Estacion;

	public SAEstacionImp() {
		this._DAO_Estacion = new FactoriaDAOBDImp().getDAOEstacion();
	}

	@Override
	public TransferEstacion Buscar(String nombre, String localidad) {
		TransferEstacion te = this._DAO_Estacion.buscar(nombre, localidad);

		return te;
	}

	@Override
	public boolean CrearEstacion(TransferEstacion te) {
		if (this._DAO_Estacion.buscar(te.getNombre(), te.getLocalidad()) != null) {
			throw new IllegalArgumentException(
					"La estacion con nombre %s y localidad %s ya existe".formatted(te.getNombre(), te.getLocalidad()));
		}
		if (!this._DAO_Estacion.darAlta(te)) {
			throw new IllegalArgumentException("No se pudo guardar la estacion en la base de datos");
		}
		return true;
	}

	@Override
	public void ModificarEstacion(TransferEstacion te) {
		if (this._DAO_Estacion.buscar(te.getNombre(), te.getLocalidad()) == null) {
			throw new IllegalArgumentException(
					"La estacion con nombre %s y localidad %s ya existe".formatted(te.getNombre(), te.getLocalidad()));
		}
		//
	}

	@Override
	public boolean EliminarEstacion(String nombre, String localidad) {
		if (this._DAO_Estacion.buscar(nombre, localidad) == null) {
			throw new IllegalArgumentException("No se encontro la estacion en la base de datos");
		}

		if (!this._DAO_Estacion.darBaja(nombre, localidad)) {
			throw new IllegalArgumentException("No se pudo eliminar la estacion en la BBDD");
		}
		return true;
	}

	@Override
	public Collection<String> getNombresEstaciones() {
		return _DAO_Estacion.buscarNombresEstaciones();
	}

	@Override
	public Collection<String> getLocalidadesEstaciones() {
		return _DAO_Estacion.buscarLocalidadesEstaciones();
	}

}
