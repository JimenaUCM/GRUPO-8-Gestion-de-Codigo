package negocio;

import java.util.Collection;
import java.util.List;

import integracion.DAOServicio;
import integracion.FactoriaDAOBDImp;

public class SAServicioImp implements SAServicio {
	private DAOServicio _DAO_Servicio;

	public SAServicioImp() {
		this._DAO_Servicio = new FactoriaDAOBDImp().getDAOServicio();
	}

	@Override
	public boolean CrearServicio(TransferServicio ts) {
		if (this._DAO_Servicio.buscar(ts.get_nombre()) != null) {
			throw new IllegalArgumentException("Ya existe el servicio con nombre " + ts.get_nombre());
		}
		if (!this._DAO_Servicio.darAlta(ts)) {
			throw new IllegalArgumentException("No se pudo guarda en la base de datos el servicio");
		}
		return true;
	}

	@Override
	public boolean ModificarServicio(TransferServicio ts) {
		this._DAO_Servicio.actualizar(ts);
		return true;
	}

	@Override
	public boolean EliminarServicio(String servicio) {
		TransferServicio ts = _DAO_Servicio.buscar(servicio);
		if (ts == null) {
			throw new IllegalArgumentException("No existe el servicio " + servicio);
		}
		if (!this._DAO_Servicio.darBaja(servicio)) {
			throw new IllegalArgumentException("No se pudo eliminar el servicio de la base de datos");
		}
		return true;
	}

	@Override
	public TransferServicio BuscarServicio(String nombre) {
		return this._DAO_Servicio.buscar(nombre);
	}

	@Override
	public Collection<TransferServicio> lista_servicio() {
		return this._DAO_Servicio.buscarListaServicios();
	}

}
