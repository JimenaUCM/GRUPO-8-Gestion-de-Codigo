package negocio;

import java.util.Collection;
import java.util.List;

import integracion.DAOBillete;
import integracion.FactoriaDAOBDImp;
import util.Fecha;
import util.Pair;

public class SABilleteImp implements SABillete {
	private DAOBillete _DAO_Billete;

	public SABilleteImp() {
		this._DAO_Billete = new FactoriaDAOBDImp().getDAOBillete();
	}

	@Override
	public void CrearBillete(TransferTren tren) {
		if (!this._DAO_Billete.darAlta(tren)) {
			throw new IllegalArgumentException("No se pudo dar de alta los billetes en la base de datos");
		}
	}

	@Override
	public void ModificarBillete(TransferBillete tb) {
		this._DAO_Billete.actualizar(tb);
	}

	@Override
	public TransferBillete Buscar(String idTren) {

		Collection<TransferBillete> billetes = this._DAO_Billete.BuscarBilleteTren(idTren);
		for (TransferBillete billete : billetes) {
			if (billete.isEstaDisponible()) {
				return billete;
			}
		}
		throw new IllegalArgumentException("No queda viaje disponibles");
	}

	@Override
	public Collection<TransferBillete> Buscar(TransferCliente tc) {
		return this._DAO_Billete.BuscarBilleteCliente(tc.getDni());
	}

	@Override
	public void ComprarBillete(TransferCliente cliente, TransferBillete billete) {
		FactoriaSA factoria = new FactoriaSAImp();
		factoria.getInstanciaSACliente().pagar(cliente, billete);
		billete.setCliente(cliente);
		billete.setEstaDisponible(false);
		ModificarBillete(billete);
	}
}
