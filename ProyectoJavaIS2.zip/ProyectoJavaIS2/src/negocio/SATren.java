package negocio;

import java.util.List;

import util.Fecha;

public interface SATren {

	public boolean EliminarTren(String id);

	public boolean CrearTren(TransferTren tt);

	public boolean Modificar(TransferTren tt);

	public TransferTren Buscar(String id);

	public List<TransferTren> BuscarTrenes(TransferEstacion origen, TransferEstacion destino, TipoTren t_tren,
			Fecha fecha);

}
