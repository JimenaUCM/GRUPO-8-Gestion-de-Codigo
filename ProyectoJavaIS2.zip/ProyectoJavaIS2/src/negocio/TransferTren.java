package negocio;

import java.util.Iterator;
import java.util.List;

import util.Horario;

public class TransferTren {
	private String _id;
	private Horario _horaSalida;
	private List<TransferBillete> _billetes;
	private TipoTren _tipoTren;
	private TransferRuta _ruta;

	public TransferTren(String id, Horario horaSalida, TipoTren tipoTren, TransferRuta ruta) {
		validate(id);

		this._id = id;
		this._horaSalida = horaSalida;
		this._tipoTren = tipoTren;
		this._ruta = ruta;

	}

	public TransferTren(TransferTren tren) {
		this(tren._id, tren._horaSalida, tren._tipoTren, tren._ruta);
	}

	private void validate(String s) {
		if (s == null || s.trim().length() == 0) {
			throw new IllegalArgumentException(s + " casilla vacia");
		}
	}

	public TipoTren getTipoTren() {
		return _tipoTren;
	}

	public void setTipoTren(TipoTren tipoTren) {
		this._tipoTren = tipoTren;
	}

	public String getId() {
		return _id;
	}

	public void setId(String id) {
		this._id = id;
	}

	public Horario getHoraSalida() {
		return _horaSalida;
	}

	public void setHoraSalida(Horario horaSalida) {
		this._horaSalida = horaSalida;
	}

	public Iterator<TransferBillete> getBilletesIterator() {
		return this._billetes.iterator();
	}

	public TransferRuta getRuta() {
		return _ruta;
	}

	public void setRuta(TransferRuta ruta) {
		this._ruta = ruta;
	}

}
