package negocio;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import integracion.DAOTren;
import integracion.FactoriaDAOBDImp;
import util.Fecha;

public class SATrenImp implements SATren {
	private DAOTren _DAO_Tren;

	public SATrenImp() {
		_DAO_Tren = new FactoriaDAOBDImp().getDAOTren();
	}

	@Override
	public boolean EliminarTren(String id) {
		if (this.Buscar(id) == null) {
			throw new IllegalArgumentException("No existe el tren con id " + id);
		}
		if (!this._DAO_Tren.darBaja(id)) {
			throw new IllegalArgumentException("El tren con id:" + id + " no se pudo eliminar");
		}
		return true;
	}

	@Override
	public boolean CrearTren(TransferTren tt) {
		if (this._DAO_Tren.buscarId(tt.getId()) != null) {
			throw new IllegalArgumentException("Ya existe el tren " + tt.getId());
		}
		if (!this._DAO_Tren.darAlta(tt)) {
			throw new IllegalArgumentException("Problema a crear el tren en la base de datos");
		}
		return true;
	}

	@Override
	public List<TransferTren> BuscarTrenes(TransferEstacion origen, TransferEstacion destino, TipoTren t_tren,
			Fecha fecha) {
		Collection<TransferTren> coleccion = this._DAO_Tren.buscarViaje(origen, destino, t_tren, fecha);
		List<TransferTren> lista = new ArrayList<>();
		for (TransferTren x : coleccion) {
			lista.add(x);
		}

		return lista;
	}

	@Override
	public TransferTren Buscar(String id) {
		return this._DAO_Tren.buscarId(id);
	}

	@Override
	public boolean Modificar(TransferTren tt) {
		if (this._DAO_Tren.buscarId(tt.getId()) == null) {
			throw new IllegalArgumentException("No existe el tren con id " + tt.getId());
		}
		if (!this._DAO_Tren.actualizar(tt)) {
			throw new IllegalArgumentException("No se pudo modificar el tren en la base de datos");
		}
		return true;
	}

}
