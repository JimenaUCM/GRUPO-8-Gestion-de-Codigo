package negocio;

import java.util.List;
import java.util.Objects;


public class TransferCliente extends TransferUsuario {
	private int _saldo;
	private List<TransferBillete> _billetes;

	public TransferCliente(String nombre, String apellidos, String dni, String password, int saldo) {
		super(nombre, apellidos, dni, password);
		validate(saldo);
		_saldo = saldo;

	}

	private void validate(int i) {
		if (i < 0)
			throw new IllegalArgumentException(i + " is negative");
	}

	public TransferCliente(String nombre, String apellidos, String dni, String password) {
		super(nombre, apellidos, dni, password);
		_saldo = 0;
	}

	public TransferCliente(TransferUsuario usuario, int saldo) {
		super(usuario);
		_saldo = saldo;
	}

	public int getSaldo() {
		return _saldo;
	}

	public void setSaldo(int saldo) {
		validate(saldo);
		_saldo = saldo;
	}

	public List<TransferBillete> getBilletes() {
		return _billetes;
	}

	public void setBilletes(List<TransferBillete> _billetes) {
		this._billetes = _billetes;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(_saldo);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransferCliente other = (TransferCliente) obj;
		return _saldo == other._saldo;
	}

}
