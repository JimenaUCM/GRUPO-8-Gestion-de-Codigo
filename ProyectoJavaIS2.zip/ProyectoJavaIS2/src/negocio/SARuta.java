package negocio;

public interface SARuta {
	public boolean CrearRuta(TransferRuta tr);

	public boolean EliminarRuta(String ruta);

	public TransferRuta BuscarRuta(String ruta);
}
