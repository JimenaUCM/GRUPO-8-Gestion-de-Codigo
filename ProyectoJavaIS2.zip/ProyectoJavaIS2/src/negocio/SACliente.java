package negocio;

import java.util.Collection;
import java.util.List;

import util.Fecha;

public interface SACliente {
	public List<TransferTren> buscarViaje(TransferEstacion origen, TransferEstacion destino, TipoTren tipoTren,
			Fecha fecha);

	public TransferBillete ElegirBillete(TransferTren tren);

	public TransferBillete Servicio_extras(TransferBillete billete, List<TransferServicio> servicios);

	public TransferCliente anularBillete(TransferBillete billete, TransferCliente cliente);

	public TransferCliente pagar(TransferCliente cliente, TransferBillete billete);

	public Collection<TransferBillete> consultarViajeRealizados(TransferCliente cliente);

	public void valorar(TransferBillete billete, int valoracion);

	public Collection<TransferBillete> conseguirBilletes(TransferCliente cliente);

	public TransferCliente anyadirDinero(TransferCliente cliente, int dinero);

	public boolean AltaCliente(TransferCliente cliente);

	public TransferCliente buscarCliente(String dni);

	public TransferCliente IniciarSesion(String dni, String contrasena);
}
