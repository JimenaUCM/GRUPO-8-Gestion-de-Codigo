package negocio;

public class TransferEstacion {
	private String _nombre;
	private String _localidad;

	public TransferEstacion(String nombre, String localidad) {
		validate(nombre);
		validate(localidad);
		_nombre = nombre;
		_localidad = localidad;

	}

	private void validate(String s) {
		if (s == null || s.trim().length() == 0) {
			throw new IllegalArgumentException("Algun campo vacio");
		}
	}

	public String getNombre() {
		return _nombre;
	}

	public void setNombre(String nombre) {
		this._nombre = nombre;
	}

	public String getLocalidad() {
		return _localidad;
	}

	public void setLocalidad(String localidad) {
		this._localidad = localidad;
	}

}
