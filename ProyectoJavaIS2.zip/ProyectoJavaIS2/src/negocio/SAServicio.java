package negocio;

import java.util.Collection;
import java.util.List;

public interface SAServicio {
	public boolean CrearServicio(TransferServicio ts);

	public boolean ModificarServicio(TransferServicio ts);

	public boolean EliminarServicio(String servicio);

	public TransferServicio BuscarServicio(String nombre);

	public Collection<TransferServicio> lista_servicio();

}
