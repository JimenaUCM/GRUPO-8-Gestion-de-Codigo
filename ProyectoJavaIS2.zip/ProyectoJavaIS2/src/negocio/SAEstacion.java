package negocio;

import java.util.Collection;

public interface SAEstacion {
	public TransferEstacion Buscar(String nombre, String localidad);

	public boolean CrearEstacion(TransferEstacion te);

	public void ModificarEstacion(TransferEstacion te);

	public boolean EliminarEstacion(String nombre, String localidad);

	public Collection<String> getNombresEstaciones();

	public Collection<String> getLocalidadesEstaciones();
}
