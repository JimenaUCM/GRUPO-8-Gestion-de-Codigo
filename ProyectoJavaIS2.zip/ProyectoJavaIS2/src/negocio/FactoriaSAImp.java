package negocio;

public class FactoriaSAImp implements FactoriaSA {

	private SABillete _saBillete = null;
	private SAAdmin _saAdmin = null;
	private SACliente _saCliente = null;
	private SARuta _saRuta = null;
	private SAServicio _saServicio = null;
	private SATren _saTren = null;
	private SAEstacion _saEstacion = null;

	@Override
	public SABillete getInstanciaSABillete() {
		if (_saBillete == null)
			_saBillete = new SABilleteImp();
		return this._saBillete;
	}

	@Override
	public SAAdmin getInstanciaSAAdmin() {
		if (this._saAdmin == null)
			this._saAdmin = new SAAdminImp();
		return _saAdmin;
	}

	@Override
	public SACliente getInstanciaSACliente() {
		if (this._saCliente == null)
			this._saCliente = new SAClienteImp();
		return _saCliente;

	}

	@Override
	public SARuta getInstanciaSARuta() {
		if (this._saRuta == null)
			this._saRuta = new SARutaImp();
		return this._saRuta;
	}

	@Override
	public SAServicio getInstanciaSAServicio() {
		if (this._saServicio == null)
			this._saServicio = new SAServicioImp();
		return _saServicio;
	}

	@Override
	public SATren getInstanciaSATren() {
		if (this._saTren == null)
			this._saTren = new SATrenImp();
		return this._saTren;
	}

	@Override
	public SAEstacion getInstanciaSAEstacion() {
		if (this._saEstacion == null)
			this._saEstacion = new SAEstacionImp();
		return this._saEstacion;
	}

}
