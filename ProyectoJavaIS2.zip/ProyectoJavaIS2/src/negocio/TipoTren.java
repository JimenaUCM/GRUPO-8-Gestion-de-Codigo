package negocio;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

public enum TipoTren {
	AltaVelocidad("Alta velocidad", 1.25), Estandar("Estandar", 1.0), Economico("Economico", 0.75);

	private String _nombre;
	private double _multiplicadorPrecio;
	public static final List<TipoTren> TIPO_TREN = Arrays.asList(AltaVelocidad, Estandar, Economico);

	private TipoTren(String nombre, double multiplicadorPrecio) {
		_nombre = nombre;
		_multiplicadorPrecio = multiplicadorPrecio;
	}

	public double getMultiplicadorPrecio() {
		return _multiplicadorPrecio;
	}

	public String toString() {
		return _nombre;
	}

	public static List<String> getListaTipoTren() {

		List<String> buffer = new ArrayList<>();
		int typeCount = 0;
		for (TipoTren tt : TipoTren.values()) {
			buffer.add(tt.name());
		}
		return buffer;
	}

}
