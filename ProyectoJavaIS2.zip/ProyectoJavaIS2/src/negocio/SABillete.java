package negocio;

import java.util.Collection;
import java.util.List;

import util.Fecha;
import util.Pair;

public interface SABillete {
	public void CrearBillete(TransferTren tren);

	public void ModificarBillete(TransferBillete billete);

	public Collection<TransferBillete> Buscar(TransferCliente cliente);

	public TransferBillete Buscar(String idTren);

	void ComprarBillete(TransferCliente cliente, TransferBillete billete);
}
