package negocio;

public class TransferServicio {
	private String _nombre;
	private int _precio;

	public TransferServicio(String nombre, int precio) {
		validate(nombre);
		validate(precio);
		this._nombre = nombre;
		this._precio = precio;
	}

	private void validate(String s) {
		if (s == null || s.trim().length() == 0) {
			throw new IllegalArgumentException(s + " vacio");
		}
	}

	private void validate(int i) {
		if (i < 0) {
			throw new IllegalArgumentException(i + " is negative");
		}
	}

	public String get_nombre() {
		return _nombre;
	}

	public void set_nombre(String nombre) {
		this._nombre = nombre;
	}

	public int get_precio() {
		return _precio;
	}

	public void set_precio(int precio) {
		this._precio = precio;
	}

}
