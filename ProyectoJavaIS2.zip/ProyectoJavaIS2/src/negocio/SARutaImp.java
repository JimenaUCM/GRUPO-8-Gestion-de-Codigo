package negocio;

import integracion.DAORuta;
import integracion.FactoriaDAOBDImp;

public class SARutaImp implements SARuta {

	private DAORuta _DAO_Ruta;

	public SARutaImp() {
		this._DAO_Ruta = new FactoriaDAOBDImp().getDAORuta();
	}

	@Override
	public boolean CrearRuta(TransferRuta ruta) {
		if (this._DAO_Ruta.buscar(ruta.getNombre()) != null) {
			throw new IllegalArgumentException("Ya existe la ruta " + ruta.getNombre());
		}
		if (!this._DAO_Ruta.darAlta(ruta)) {
			throw new IllegalArgumentException("No se pudo crear la ruta en la base de datos");
		}
		return true;
	}

	@Override
	public boolean EliminarRuta(String ruta) {
		if (this._DAO_Ruta.buscar(ruta) == null) {
			throw new IllegalArgumentException("No existe la ruta " + ruta);
		}
		if (!this._DAO_Ruta.darBaja(ruta)) {
			throw new IllegalArgumentException("Problema ha eliminar ruta de la BBDD");
		}
		return true;
	}

	@Override
	public TransferRuta BuscarRuta(String ruta) {
		return this._DAO_Ruta.buscar(ruta);
	}

}
