package negocio;

public class TransferAdmin extends TransferUsuario {

	public TransferAdmin(String nombre, String apellidos, String dni, String password) {
		super(nombre, apellidos, dni, password);
	}

	public TransferAdmin(TransferUsuario usuario) {
		super(usuario);
	}

}
