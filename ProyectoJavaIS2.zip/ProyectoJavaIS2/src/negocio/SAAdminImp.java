package negocio;

import integracion.DAOAdmin;
import integracion.DAOCliente;
import integracion.FactoriaDAOBDImp;
import util.Horario;

public class SAAdminImp implements SAAdmin {

	private DAOAdmin _DAO_Admin;
	private final String _password_admin = "123";
	private FactoriaSA factoria;

	public SAAdminImp() {
		this._DAO_Admin = new FactoriaDAOBDImp().getDAOAdmin();
		factoria = new FactoriaSAImp();
	}

	@Override
	public boolean modificarServicio(String nombre, int precio) {
		TransferServicio ts = new TransferServicio(nombre, precio);
		return this.factoria.getInstanciaSAServicio().ModificarServicio(ts);
	}

	@Override
	public boolean crearServicio(String nombre, int precio) {
		TransferServicio ts = new TransferServicio(nombre, precio);
		return this.factoria.getInstanciaSAServicio().CrearServicio(ts);
	}

	@Override
	public boolean eliminarServicio(String nombre) {
		return this.factoria.getInstanciaSAServicio().EliminarServicio(nombre);
	}

	@Override
	public boolean crearRuta(String nombre, TransferEstacion origen, TransferEstacion destino, int duracion,
			int precio) {
		TransferRuta tr = new TransferRuta(nombre, origen, destino, duracion, precio);
		return this.factoria.getInstanciaSARuta().CrearRuta(tr);
	}

	@Override
	public boolean eliminarRuta(String nombre) {
		return this.factoria.getInstanciaSARuta().EliminarRuta(nombre);
	}

	@Override
	public boolean crearEstacion(String nombre, String localidad) {
		TransferEstacion te = new TransferEstacion(nombre, localidad);
		return this.factoria.getInstanciaSAEstacion().CrearEstacion(te);
	}

	@Override
	public boolean eliminarEstacion(String nombre, String localidad) {
		return this.factoria.getInstanciaSAEstacion().EliminarEstacion(nombre, localidad);
	}

	@Override
	public boolean crearTren(String id_tren, Horario salida, String ruta, TipoTren t_tren) {
		TransferRuta tr = this.factoria.getInstanciaSARuta().BuscarRuta(ruta);
		TransferTren tt = new TransferTren(id_tren, salida, t_tren, tr);
		boolean bReturn = this.factoria.getInstanciaSATren().CrearTren(tt);
		this.factoria.getInstanciaSABillete().CrearBillete(tt);
		return bReturn;
	}

	@Override
	public boolean modificarTren(String id_tren, Horario salida, String ruta, TipoTren t_tren) {
		TransferRuta tr = this.factoria.getInstanciaSARuta().BuscarRuta(ruta);
		TransferTren tt = new TransferTren(id_tren, salida, t_tren, tr);
		return this.factoria.getInstanciaSATren().Modificar(tt);
	}

	@Override
	public boolean eliminarTren(String id_tren) {
		return this.factoria.getInstanciaSATren().EliminarTren(id_tren);
	}

	@Override
	public boolean AltaAdmin(TransferAdmin admin, String contrasenaSistema) {
		if (!this._password_admin.equals(contrasenaSistema)) {
			throw new IllegalArgumentException("La clave de administrador es invalido");
		}
		return this._DAO_Admin.darAlta(admin);
	}

	@Override
	public TransferAdmin IniciarSesion(String dni, String contrasena) {
		TransferAdmin admin = this._DAO_Admin.buscar(dni);
		if (admin == null) {
			throw new IllegalArgumentException("Cliente no existe");
		}
		if (!admin.getPassword().equals(contrasena)) {
			throw new IllegalArgumentException("Contraseña incorrecta");
		}

		return admin;
	}

	@Override
	public TransferAdmin BuscarAdmin(String dni) {
		return this._DAO_Admin.buscar(dni);
	}

}
