package negocio;

public class TransferRuta {
	private String _nombre;
	private int _precio;
	private int _duracion;
	private TransferEstacion _origen;
	private TransferEstacion _destino;

	public TransferRuta(String nombre, TransferEstacion origen, TransferEstacion destino, int duracion, int precio) {
		validate(nombre);
		validate(duracion);
		validate(precio);

		this._origen = origen;
		this._destino = destino;
		this._nombre = nombre;
		this._precio = precio;
		this._duracion = duracion;
	}

	private void validate(String s) {
		if (s == null || s.trim().length() == 0) {
			throw new IllegalArgumentException(s + " vacio");
		}
	}

	private void validate(int i) {
		if (i <= 0) {
			throw new IllegalArgumentException(i + " is negative");
		}
	}

	public String getNombre() {
		return _nombre;
	}

	public void setNombre(String ruta) {
		this._nombre = ruta;
	}

	public int getPrecio() {
		return _precio;
	}

	public void setPrecio(int precio) {
		this._precio = precio;
	}

	public int getDuracion() {
		return this._duracion;
	}

	public void setDuracion(int duration) {
		this._duracion = duration;
	}

	public TransferEstacion getEstacionOrigen() {
		return _origen;
	}

	public void setEstacionOrigen(TransferEstacion origen) {
		this._origen = origen;
	}

	public TransferEstacion getEstacionDestino() {
		return _destino;
	}

	public void setEstacionDestino(TransferEstacion destino) {
		this._destino = destino;
	}

}
