package negocio;

public interface FactoriaSA {
	public SABillete getInstanciaSABillete();

	public SAAdmin getInstanciaSAAdmin();

	public SACliente getInstanciaSACliente();

	public SARuta getInstanciaSARuta();

	public SAServicio getInstanciaSAServicio();

	public SATren getInstanciaSATren();

	public SAEstacion getInstanciaSAEstacion();
}
