package negocio;

import java.util.Objects;

public class TransferUsuario {
	private String _nombre;
	private String _apellidos;
	private String _dni;
	private String _password;

	public TransferUsuario(String nombre, String apellidos, String dni, String password) {
		validate(nombre);
		validate(apellidos);
		validate(password);
		validarDNI(dni);

		_nombre = nombre;
		_apellidos = apellidos;
		_dni = dni;
		_password = password;
	}

	private void validarDNI(String dni) {
		if (dni.length() != 9)
			throw new IllegalArgumentException("DNI inválido, tamaño inválido");
		else if (!Character.isLetter(dni.charAt(8)))
			throw new IllegalArgumentException("DNI inválido, ultimo valor letra");
		else {
			String number = dni.substring(0, 8);
			try {
				Integer.parseInt(number);
			} catch (NumberFormatException n) {
				throw new IllegalArgumentException("DNI inválido, los primeros no son numeros");
			}
		}
	}

	private void validate(String s) {
		if (s == null || s.trim().length() == 0) {
			throw new IllegalArgumentException(s + " casilla vacia");
		}
	}

	public TransferUsuario(TransferUsuario usuario) {
		this(usuario._nombre, usuario._apellidos, usuario._dni, usuario._password);
	}

	public String getNombre() {
		return _nombre;
	}

	public void setNombre(String nombre) {
		validate(nombre);
		this._nombre = nombre;
	}

	public String getApellidos() {
		return _apellidos;
	}

	public void setApellidos(String apellidos) {
		validate(apellidos);
		this._apellidos = apellidos;
	}

	public String getDni() {
		return _dni;
	}

	public void setDni(String dni) {
		validarDNI(dni);
		this._dni = dni;
	}

	public String getPassword() {
		return _password;
	}

	public void setPassword(String password) {
		validate(password);
		this._password = password;
	}

	@Override
	public int hashCode() {
		return Objects.hash(_apellidos, _dni, _nombre, _password);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransferUsuario other = (TransferUsuario) obj;
		return Objects.equals(_apellidos, other._apellidos) && Objects.equals(_dni, other._dni)
				&& Objects.equals(_nombre, other._nombre) && Objects.equals(_password, other._password);
	}
}
