package negocio;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import integracion.DAOCliente;
import integracion.FactoriaDAOBDImp;
import util.Fecha;

public class SAClienteImp implements SACliente {

	private DAOCliente _DAO_Cliente;

	private FactoriaSA _factoria;

	public SAClienteImp() {
		_DAO_Cliente = new FactoriaDAOBDImp().getDAOCliente();
		this._factoria = new FactoriaSAImp();
	}

	@Override
	public TransferCliente IniciarSesion(String dni, String contrasena) {
		TransferCliente cliente = this._DAO_Cliente.buscar(dni);
		if (cliente == null) {
			return null;
		}
		if (!cliente.getPassword().equals(contrasena)) {
			throw new IllegalArgumentException("Contraseña incorrecta");
		}

		return cliente;
	}

	@Override
	public TransferCliente pagar(TransferCliente cliente, TransferBillete billete) {
		TransferCliente tc = _DAO_Cliente.buscar(cliente.getDni());
		if (billete == null) {
			throw new IllegalArgumentException("No se encontro el billete a la hora de pagar");
		}
		if (tc == null) {
			throw new IllegalArgumentException("El usuario con DNI " + cliente.getDni() + " no existe a la hora");
		}

		if (tc.getSaldo() < billete.getPrecio()) {
			throw new IllegalArgumentException("El cliente no posee saldo suficiente , saldo actual: " + tc.getSaldo()
					+ " coste :" + billete.getPrecio());
		} else {
			tc.setSaldo(tc.getSaldo() - billete.getPrecio());
			this._DAO_Cliente.actualizar(tc);
			billete.setEstaDisponible(false);
		}
		return tc;

	}

	@Override
	public TransferCliente anularBillete(TransferBillete billete, TransferCliente cliente) {
		if (billete == null) {
			throw new IllegalArgumentException("El billete no existe");
		}

		billete.setEstaDisponible(true);
		billete.setValoracion(-1);
		int precio = billete.getPrecio();
		int precio_servicio = 0;
		TransferServicio ts;
		Iterator<TransferServicio> it = billete.getServicio();
		while (it.hasNext()) {
			ts = it.next();
			precio_servicio += ts.get_precio();
		}
		billete.setPrecio(precio - precio_servicio);
		this._factoria.getInstanciaSABillete().ModificarBillete(billete);

		cliente.setSaldo(cliente.getSaldo() + precio);
		this._DAO_Cliente.actualizar(cliente);
		return cliente;

	}

	@Override
	public Collection<TransferBillete> consultarViajeRealizados(TransferCliente cliente) {
		return this._factoria.getInstanciaSABillete().Buscar(cliente);
	}

	@Override
	public void valorar(TransferBillete billete, int valoracion) {
		billete.setValoracion(valoracion);
		this._factoria.getInstanciaSABillete().ModificarBillete(billete);

	}

	public List<TransferTren> buscarViaje(TransferEstacion origen, TransferEstacion destino, TipoTren tipoTren,
			Fecha fecha) {
		List<TransferTren> trenes = this._factoria.getInstanciaSATren().BuscarTrenes(origen, destino, tipoTren, fecha);
		if (trenes.isEmpty()) {
			throw new IllegalArgumentException("No existe viajes");
		}

		return trenes;
	}

	@Override
	public TransferBillete ElegirBillete(TransferTren tren) {
		TransferBillete billete = this._factoria.getInstanciaSABillete().Buscar(tren.getId());
		if (billete == null) {
			throw new IllegalArgumentException("No quedan asientos libres en el tren " + tren.getId());
		}
		return billete;
	}

	@Override
	public Collection<TransferBillete> conseguirBilletes(TransferCliente cliente) {
		return this._factoria.getInstanciaSABillete().Buscar(cliente);
	}

	@Override
	public TransferBillete Servicio_extras(TransferBillete billete, List<TransferServicio> servicios) {
		int precio = 0;
		for (TransferServicio x : servicios) {
			precio += x.get_precio();
		}
		billete.setPrecio(billete.getPrecio() + precio);

		return billete;
	}

	@Override
	public TransferCliente anyadirDinero(TransferCliente cliente, int dinero) {
		cliente.setSaldo(cliente.getSaldo() + dinero);
		if (!this._DAO_Cliente.actualizar(cliente)) {
			cliente.setSaldo(cliente.getSaldo() - dinero); 
															
		}

		return cliente;
	}

	@Override
	public boolean AltaCliente(TransferCliente cliente) {
		return this._DAO_Cliente.darAlta(cliente);
	}

	@Override
	public TransferCliente buscarCliente(String dni) {
		return this._DAO_Cliente.buscar(dni);

	}

}
