package negocio;

import util.Horario;

public interface SAAdmin {
	public boolean modificarServicio(String nombre, int precio);

	public boolean crearServicio(String nombre, int precio);

	public boolean eliminarServicio(String nombre);

	public boolean crearRuta(String nombre, TransferEstacion origen, TransferEstacion destino, int duracion,
			int precio);

	public boolean eliminarRuta(String nombre);

	public boolean crearTren(String id_tren, Horario salida, String ruta, TipoTren t_tren);

	public boolean modificarTren(String id_tren, Horario salida, String ruta, TipoTren t_tren);

	public boolean eliminarTren(String id_tren);

	public boolean crearEstacion(String nombre, String localidad);

	public boolean eliminarEstacion(String nombre, String localidad);

	public boolean AltaAdmin(TransferAdmin admin, String contrasenaSistema);

	public TransferAdmin IniciarSesion(String dni, String contrasena);

	public TransferAdmin BuscarAdmin(String dni);
}
