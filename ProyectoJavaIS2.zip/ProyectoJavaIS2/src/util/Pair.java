package util;

public class Pair<First_type, Second_type> {
	public First_type first;
	public Second_type second;

	public Pair(First_type first, Second_type second) {
		if (first == null) {
			throw new IllegalArgumentException("The value of the first atributte can not be null");
		}
		if (second == null) {
			throw new IllegalArgumentException("The value of the second atributte can not be null");
		}
		this.first = first;
		this.second = second;
	}

}
