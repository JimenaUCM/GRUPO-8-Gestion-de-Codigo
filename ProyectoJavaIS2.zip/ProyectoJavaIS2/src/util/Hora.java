package util;

public class Hora {

	private int _segundos;
	private int _minutos;
	private int _horas;

	private static final String FORMATO_HORA = "%02d:%02d:%02d"; // HH:MM:SS
	private static final String[] NOMBRE_FORMATO = { "Hora", "Minuto", "Segundo" };

	public Hora( int horas, int minutos, int segundos) {
		if (segundos < 0 || segundos >= 60) {
			throw new IllegalArgumentException("Segundo invalido:" + segundos);
		}
		if (minutos < 0 || minutos >= 60) {
			throw new IllegalArgumentException("Minuto invalido:" + minutos);
		}
		if (horas < 0 || horas >= 24) {
			throw new IllegalArgumentException("Hora invalido:" + horas);
		}
		this._segundos = segundos;
		this._minutos = minutos;
		this._horas = horas;
	}

	static public Hora parseHora(String hora) {
		if (hora == null || hora.trim().length() == 0) {
			throw new IllegalArgumentException("Hora invalida (" + hora + ")");
		}
		String[] horaSeparada = hora.split("\\:");
		if (horaSeparada.length != 3) {
			throw new IllegalArgumentException("Hora invalida (" + hora + ")");
		}

		int[] horaInt = new int[3];
		for (int i = 0; i < 3; i++) {
			try {
				horaInt[i] = Integer.parseInt(horaSeparada[i]);
			} catch (NumberFormatException e) {
				throw new IllegalArgumentException(NOMBRE_FORMATO[i] + " invalido:" + horaSeparada[i]);
			}
		}
		return new Hora(horaInt[0], horaInt[1], horaInt[2]);
	}

	public boolean menor(Hora hora) {
		if (this._horas != hora._horas) {
			return _horas < hora._horas;
		} else if (this._minutos != hora._minutos) {
			return _minutos < hora._minutos;
		} else {
			return _segundos < hora._segundos;
		}
	}

	public boolean equals(Hora hora) {
		return _horas == hora._horas && _minutos == hora._minutos && _segundos == hora._segundos;
	}

	public boolean menorEquals(Hora hora) {
		return equals(hora) || menor(hora);
	}

	public boolean mayor(Hora hora) {
		return !menorEquals(hora);
	}

	public boolean mayorEquals(Hora hora) {
		return !menor(hora);
	}

	public String toString() {
		return FORMATO_HORA.formatted(_horas, _minutos, _segundos);
	}
}
