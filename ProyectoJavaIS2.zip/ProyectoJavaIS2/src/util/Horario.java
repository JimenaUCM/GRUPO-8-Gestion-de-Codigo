package util;

public class Horario {
	private Hora _hora;
	private Fecha _fecha;

	public Horario(Fecha fecha, Hora hora) {
		this._fecha = fecha;
		this._hora = hora;
	}

	static public Horario parseHorario(String horario) {
		if (horario == null || horario.trim().length() == 0) {
			throw new IllegalArgumentException("Hora invalida (" + horario + ")");
		}
		String[] horarioSeparado = horario.split("\\ ");
		if (horarioSeparado.length != 2) {
			throw new IllegalArgumentException("Hora invalida (" + horario + ")");
		}
		return new Horario(Fecha.parseFecha(horarioSeparado[0]), Hora.parseHora(horarioSeparado[1]));
	}

	public boolean menor(Horario horario) {
		if (this._fecha != horario._fecha) {
			return this._fecha.menor(horario._fecha);
		} else {
			return this._hora.menor(horario._hora);
		}
	}

	public boolean equals(Horario horario) {
		return this._fecha.equals(horario._fecha) && this._hora.equals(horario._hora);
	}

	public Hora getHora() {
		return _hora;
	}

	public void setHora(Hora hora) {
		this._hora = hora;
	}

	public Fecha getFecha() {
		return _fecha;
	}

	public void setFecha(Fecha fecha) {
		this._fecha = fecha;
	}

	public String toString() {
		return _fecha.toString() + " " + _hora.toString();
	}
}
