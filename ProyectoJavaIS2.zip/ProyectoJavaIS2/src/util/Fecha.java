package util;

public class Fecha {

	private int _dia;
	private int _mes;
	private int _anio;
	public static final int[] DIAS_MES = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }; // El numero de dias que
																								// puede tener cada mes
	private static final String FORMATO_HORA = "%04d-%02d-%02d"; // YYYY-MM-DD
	private static final String[] NOMBRE_FORMATO = { "Año", "Mes", "Dia" };

	public Fecha(int dia, int mes, int anio) {
		if (anio <= 0) {
			throw new IllegalArgumentException("Año invalido: " + anio);
		}
		if (mes <= 0 || mes > 12) {
			throw new IllegalArgumentException("Mes invalido: " + mes);
		}
		if (dia <= 0 || dia > DIAS_MES[mes - 1]) {
			throw new IllegalArgumentException(
					"Dia invalido: " + dia + ", el mes " + mes + " tiene " + DIAS_MES[mes - 1] + " dias");
		}
		this._dia = dia;
		this._mes = mes;
		this._anio = anio;

	}

	static public Fecha parseFecha(String fecha) {
		if (fecha == null || fecha.trim().length() == 0) {
			throw new IllegalArgumentException("Fecha invalida (" + fecha + ")");
		}
		String[] fechaSeparada = fecha.split("\\-");
		if (fechaSeparada.length != 3) {
			throw new IllegalArgumentException("Fecha invalida (" + fecha + ")");
		}

		int[] fechaInt = new int[3];
		for (int i = 0; i < 3; i++) {
			try {
				fechaInt[i] = Integer.parseInt(fechaSeparada[i]);
			} catch (NumberFormatException e) {
				throw new IllegalArgumentException(NOMBRE_FORMATO[i] + " invalido:" + fechaSeparada[i]);
			}
		}
		return new Fecha(fechaInt[2], fechaInt[1], fechaInt[0]);
	}

	public boolean menor(Fecha fecha) {
		if (this._anio != fecha._anio) {
			return _anio < fecha._anio;
		} else if (this._mes != fecha._mes) {
			return _mes < fecha._mes;
		} else {
			return _dia < fecha._dia;
		}
	}

	public boolean equals(Fecha fecha) {
		return _anio == fecha._anio && _mes == fecha._mes && _dia == fecha._dia;
	}

	public boolean menorEquals(Fecha fecha) {
		return equals(fecha) || menor(fecha);
	}

	public boolean mayor(Fecha fecha) {
		return !menorEquals(fecha);
	}

	public boolean mayorEquals(Fecha fecha) {
		return !menor(fecha);
	}

	public String toString() {
		return FORMATO_HORA.formatted(_anio % 10000, _mes % 100, _dia % 100);
	}
}
