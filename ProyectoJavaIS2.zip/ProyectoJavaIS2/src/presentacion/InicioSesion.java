package presentacion;

import java.awt.Graphics;
import java.awt.event.ActionEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class InicioSesion extends JPanel {

	private JPanel _panelPrincipal;
	private JLabel _etiquetaContraseña;
	private JLabel _etiquetaDNI;
	private JPasswordField _campoContrasena;
	private JTextField _campoDNI;
	private JButton _botonInicio;
	private JButton _botonRegistro;
	private Controlador _ctrl;

	public InicioSesion(Controlador ctrl) {
		_ctrl = ctrl;
		iniciarComponentes();
	}

	private void iniciarComponentes() {
		_panelPrincipal = new ImagenDeFondo();
		_etiquetaDNI = new JLabel();
		_etiquetaContraseña = new JLabel();
		_campoDNI = new JTextField();
		_campoContrasena = new JPasswordField();
		_botonInicio = new JButton();
		_botonRegistro = new JButton();

		_panelPrincipal.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "INICIAR SESIÓN ",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Verdana", 1, 18), new java.awt.Color(204, 0, 51))); // NOI18N

		// etiquetas
		_etiquetaDNI.setFont(new java.awt.Font("Verdana", 0, 30)); // NOI18N
		_etiquetaDNI.setText("DNI:");
		_etiquetaContraseña.setFont(new java.awt.Font("Verdana", 0, 30)); // NOI18N
		_etiquetaContraseña.setText("Contraseña:");

		// campos
		_campoDNI.setFont(new java.awt.Font("Verdana", 0, 22)); // NOI18N
		_campoContrasena.setFont(new java.awt.Font("Verdana", 0, 22)); // NOI18N

		// botones
		_botonInicio.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
		_botonInicio.setText("Iniciar");
		_botonInicio.addActionListener((e) -> botonInicioActionPerformed(e));

		_botonRegistro.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
		_botonRegistro.setText("Registrarse");
		_botonRegistro.addActionListener((e) -> botonRegistroActionPerformed(e));

		javax.swing.GroupLayout _panelPrincipalLayout = new javax.swing.GroupLayout(_panelPrincipal);
		_panelPrincipal.setLayout(_panelPrincipalLayout);
		_panelPrincipalLayout.setHorizontalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(240, 240, 240)
						.addGroup(_panelPrincipalLayout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
								.addGroup(_panelPrincipalLayout.createSequentialGroup()
										.addComponent(_botonInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 118,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(_botonRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 134,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(_panelPrincipalLayout.createSequentialGroup()
										.addGroup(_panelPrincipalLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(_etiquetaContraseña).addComponent(_etiquetaDNI))
										.addGap(27, 27, 27)
										.addGroup(_panelPrincipalLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
												.addComponent(_campoDNI, javax.swing.GroupLayout.DEFAULT_SIZE, 278,
														Short.MAX_VALUE)
												.addComponent(_campoContrasena))))
						.addContainerGap(243, Short.MAX_VALUE)));
		_panelPrincipalLayout.setVerticalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(188, 188, 188)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(_etiquetaDNI)
								.addComponent(_campoDNI, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(91, 91, 91)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_etiquetaContraseña)
								.addComponent(_campoContrasena, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(142, 142, 142)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_botonInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(_botonRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(113, 113, 113)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
		this.setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

	}

	private void botonInicioActionPerformed(ActionEvent evt) {
		JFrame padre = (JFrame) SwingUtilities.getWindowAncestor(this);
		char[] contrasena = _campoContrasena.getPassword();
		String pass = new String(contrasena);
		try {
			// SEGUN EL RETORNO DE LA FUNCION iniciarSesion() abrir una ventana u otra
			switch (_ctrl.iniciarSesion(_campoDNI.getText(), pass)) {
			case 1:
				InicioCliente inicioCliente = new InicioCliente(padre, _ctrl); // PARA CLIENTE
				break;
			case 2:
				InicioAdministrador inicioAdmin = new InicioAdministrador(padre, _ctrl); // PARA ADMIN
				break;
			case 0:
				throw new IllegalArgumentException("No existe ningun usuario registrado con ese DNI");
			}
			padre.setVisible(false); // se deja ver la principal para no tener muchas ventanas abiertas, si se le da
			// al boton volver, se pone visible otra vez la principal
		} catch (Exception e) {
			Utils.showErrorMsg(e.getMessage());
		}
	}

	private void botonRegistroActionPerformed(ActionEvent evt) { // Abrir el diaologo de Registro
		JFrame padre = (JFrame) SwingUtilities.getWindowAncestor(this);
		DialogoAdmin dialogo = new DialogoAdmin((JFrame) SwingUtilities.getWindowAncestor(this), _ctrl);
	}

	class ImagenDeFondo extends JPanel {
		@Override
		public void paint(Graphics g) {
			ImageIcon Img = new ImageIcon(("src/fondo.png"));
			g.drawImage(Img.getImage(), 0, 0, getWidth(), getHeight(), this);
			setOpaque(false);
			super.paint(g);
		}
	}
}