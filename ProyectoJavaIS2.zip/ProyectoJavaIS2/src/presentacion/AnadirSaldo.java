package presentacion;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class AnadirSaldo extends javax.swing.JFrame {

	private javax.swing.JToggleButton _botonOK;
	private javax.swing.JButton _botonVolver;
	private javax.swing.JTextField _campoSaldo;
	private javax.swing.JLabel _etiquetaSaldo;
	private javax.swing.JPanel _panelPrincipal;
	private Controlador _ctrl;
	private JFrame _ventanaPadre;

	public AnadirSaldo(JFrame padre, Controlador ctrl) {
		_ventanaPadre = padre;
		_ctrl = ctrl;
		setTitle("Añadir saldo");
		initComponents();
	}

	private void initComponents() {

		_panelPrincipal = new javax.swing.JPanel();
		_botonVolver = new javax.swing.JButton();
		_etiquetaSaldo = new javax.swing.JLabel();
		_campoSaldo = new javax.swing.JTextField();
		_botonOK = new javax.swing.JToggleButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);

		_panelPrincipal.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "AÑADIR SALDO  ",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Verdana", 1, 18), new java.awt.Color(204, 0, 51))); // NOI18N

		_botonVolver.setBackground(new java.awt.Color(255, 204, 204));
		_botonVolver.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_botonVolver.setForeground(new java.awt.Color(0, 0, 0));
		_botonVolver.setText("Volver");
		_botonVolver.addActionListener((e) -> _botonVolverActionPerformed(e));

		_etiquetaSaldo.setFont(new java.awt.Font("Verdana", 0, 24)); // NOI18N
		_etiquetaSaldo.setText("Saldo a añadir:");

		_campoSaldo.setFont(new java.awt.Font("Verdana", 0, 24)); // NOI18N

		_botonOK.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_botonOK.setText("OK");
		_botonOK.setBackground(new java.awt.Color(255, 204, 204));
		_botonOK.setForeground(new java.awt.Color(0, 0, 0));
		_botonOK.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				_botonOKActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout _panelPrincipalLayout = new javax.swing.GroupLayout(_panelPrincipal);
		_panelPrincipal.setLayout(_panelPrincipalLayout);
		_panelPrincipalLayout.setHorizontalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(136, 136, 136)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addComponent(_botonOK).addComponent(_etiquetaSaldo))
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(57, 57, 57)
										.addComponent(_campoSaldo, javax.swing.GroupLayout.PREFERRED_SIZE, 278,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(133, Short.MAX_VALUE))
								.addGroup(_panelPrincipalLayout.createSequentialGroup()
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(_botonVolver).addGap(221, 221, 221)))));
		_panelPrincipalLayout.setVerticalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(100, 100, 100)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addComponent(_etiquetaSaldo).addComponent(_campoSaldo,
										javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_botonOK).addComponent(_botonVolver))
						.addGap(70, 70, 70)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				_panelPrincipal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
		if (_ventanaPadre != null) // centrar en la ventana principal
			setLocation(_ventanaPadre.getLocation().x + _ventanaPadre.getWidth() / 2 - getWidth() / 2,
					_ventanaPadre.getLocation().y + _ventanaPadre.getHeight() / 2 - getHeight() / 2);
		setVisible(true);
	}

	private void _botonVolverActionPerformed(java.awt.event.ActionEvent evt) {
		// cosas
		setVisible(false);
	}

	private void _botonOKActionPerformed(java.awt.event.ActionEvent evt) {
		try {
			if (Double.parseDouble(this._campoSaldo.getText()) <= 0) {
				throw new Exception();
			}
			// llamar a controlador para sumar
			JOptionPane.showMessageDialog(null, "Saldo añadido con exito");
			setVisible(false); // y se cierra la ventana de añadir saldo
		} catch (Exception e1) {
			Utils.showErrorMsg(e1.getMessage());
		}

	}

	private void _botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {
		setVisible(false);
	}

}
