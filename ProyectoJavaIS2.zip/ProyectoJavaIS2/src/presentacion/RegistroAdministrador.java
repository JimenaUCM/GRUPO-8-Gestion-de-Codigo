package presentacion;

import java.awt.event.ActionEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import negocio.TransferAdmin;

public class RegistroAdministrador extends javax.swing.JFrame {

	private javax.swing.JButton _botonCancelar;
	private javax.swing.JButton _botonCrearCuenta;
	private javax.swing.JTextField _campoApellidos;
	private javax.swing.JPasswordField _campoContrasena;
	private javax.swing.JTextField _campoDNI;
	private javax.swing.JTextField _campoNombre;
	private javax.swing.JTextField _campoValidar;
	private javax.swing.JLabel _etiquetaApellidos;
	private javax.swing.JLabel _etiquetaContrasena;
	private javax.swing.JLabel _etiquetaDNI;
	private javax.swing.JLabel _etiquetaNombre;
	private javax.swing.JLabel _etiquetaValidar;
	private javax.swing.JPanel _panelPrincipal;
	private JFrame _ventanaPadre;
	private Controlador _ctrl;

	public RegistroAdministrador(JFrame padre, Controlador ctrl) {
		_ventanaPadre = padre;
		_ctrl = ctrl;
		setTitle("Registro administrador");
		initComponents();
	}

	private void initComponents() {

		_panelPrincipal = new javax.swing.JPanel();
		_etiquetaNombre = new javax.swing.JLabel();
		_campoContrasena = new javax.swing.JPasswordField();
		_etiquetaDNI = new javax.swing.JLabel();
		_campoNombre = new javax.swing.JTextField();
		_etiquetaApellidos = new javax.swing.JLabel();
		_campoApellidos = new javax.swing.JTextField();
		_botonCrearCuenta = new javax.swing.JButton();
		_botonCancelar = new javax.swing.JButton();
		_etiquetaContrasena = new javax.swing.JLabel();
		_campoDNI = new javax.swing.JTextField();
		_etiquetaValidar = new javax.swing.JLabel();
		_campoValidar = new javax.swing.JTextField();

		// etiquetas
		_etiquetaNombre.setFont(new java.awt.Font("Verdana", 0, 18));
		_etiquetaNombre.setText("Nombre:");

		_etiquetaApellidos.setFont(new java.awt.Font("Verdana", 0, 18));
		_etiquetaApellidos.setText("Apellidos:");

		_etiquetaDNI.setFont(new java.awt.Font("Verdana", 0, 18));
		_etiquetaDNI.setText("DNI:");

		_etiquetaContrasena.setFont(new java.awt.Font("Verdana", 0, 18));
		_etiquetaContrasena.setText("Contraseña:");

		_etiquetaValidar.setFont(new java.awt.Font("Verdana", 0, 18));
		_etiquetaValidar.setText("Validar:");

		// campos
		_campoContrasena.setFont(new java.awt.Font("Verdana", 0, 18));
		_campoNombre.setFont(new java.awt.Font("Verdana", 0, 18));
		_campoApellidos.setFont(new java.awt.Font("Verdana", 0, 18));
		_campoDNI.setFont(new java.awt.Font("Verdana", 0, 18));
		_campoValidar.setFont(new java.awt.Font("Verdana", 0, 18));

		// botones
		_botonCrearCuenta.setFont(new java.awt.Font("Verdana", 0, 18));
		_botonCrearCuenta.setText("Crear Cuenta");
		_botonCrearCuenta.addActionListener((e) -> botonCrearCuentaActionPerformed(e));

		_botonCancelar.setFont(new java.awt.Font("Verdana", 0, 18));
		_botonCancelar.setText("Cancelar");
		_botonCancelar.addActionListener((e) -> setVisible(false));

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(_panelPrincipal);
		_panelPrincipal.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addGap(69, 69, 69).addGroup(jPanel1Layout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
						.addGroup(jPanel1Layout.createSequentialGroup().addComponent(_botonCrearCuenta)
								.addGap(94, 94, 94).addComponent(_botonCancelar))
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(jPanel1Layout.createSequentialGroup().addGroup(
										jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(_etiquetaDNI).addComponent(_etiquetaApellidos)
												.addComponent(_etiquetaNombre))
										.addGap(42, 42, 42)
										.addGroup(jPanel1Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(_campoApellidos, javax.swing.GroupLayout.PREFERRED_SIZE,
														210, javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(_campoDNI, javax.swing.GroupLayout.PREFERRED_SIZE, 210,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(_campoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 210,
														javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addGroup(jPanel1Layout.createSequentialGroup().addGroup(
										jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(_etiquetaContrasena).addComponent(_etiquetaValidar))
										.addGap(18, 18, 18)
										.addGroup(jPanel1Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
												.addComponent(_campoContrasena, javax.swing.GroupLayout.DEFAULT_SIZE,
														210, Short.MAX_VALUE)
												.addComponent(_campoValidar)))))
						.addGap(0, 70, Short.MAX_VALUE)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addGap(55, 55, 55)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_etiquetaNombre)
								.addComponent(_campoNombre, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(42, 42, 42)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_etiquetaApellidos)
								.addComponent(_campoApellidos, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(50, 50, 50)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_etiquetaDNI)
								.addComponent(_campoDNI, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(51, 51, 51)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_etiquetaContrasena)
								.addComponent(_campoContrasena, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(45, 45, 45)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addComponent(_etiquetaValidar).addComponent(_campoValidar,
										javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_botonCrearCuenta).addComponent(_botonCancelar))
						.addGap(52, 52, 52)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
						.addComponent(_panelPrincipal, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(0, 0, Short.MAX_VALUE)));

		pack();
		if (_ventanaPadre != null) // centrar en la ventana principal
			setLocation(_ventanaPadre.getLocation().x + _ventanaPadre.getWidth() / 2 - getWidth() / 2,
					_ventanaPadre.getLocation().y + _ventanaPadre.getHeight() / 2 - getHeight() / 2);
		setVisible(true);
	}

	private void botonCrearCuentaActionPerformed(ActionEvent evt) {
		try {
			char[] contrasena = _campoContrasena.getPassword();
			String pass = new String(contrasena);
			TransferAdmin admin = new TransferAdmin(_campoNombre.getText(), _campoApellidos.getText(),
					_campoDNI.getText(), pass);
			if (!_ctrl.darDeAltaAdministrador(admin, _campoValidar.getText())) {
				throw new IllegalArgumentException("No se ha creado correctamente la cuenta, ha habido un error");
			}
			JOptionPane.showMessageDialog(null, "Cuenta creada con exito");
			setVisible(false);
		} catch (Exception e) { // se lanza excepcion si los datos son incorrectos
			Utils.showErrorMsg(e.getMessage());
		}
	}

}