package presentacion;

import java.util.List;

import negocio.TransferServicio;

public interface Observer { // todas las de servicio la implementan
	public void onServiceAdded(List<TransferServicio> servicios, TransferServicio s);

	public void onServiceDeleted(List<TransferServicio> servicios, TransferServicio s);

	public void onSaldoChanged(int nuevoSaldo);
	// ejemplo: metodo de añadirTren, deben invocar onServiceAdded

}
