package presentacion;

import java.awt.Graphics;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import negocio.TransferServicio;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class InicioCliente extends JFrame {
	// Panel con 4 botones, cada boton abre su propia ventana ya que representa una
	// accion que puede hacer el cliente
	private JFrame _ventanaPadre;
	private javax.swing.JButton _botonAnadirSaldo;
	private javax.swing.JButton _botonAnularViaje;
	private javax.swing.JButton _botonBuscarViaje;
	private javax.swing.JButton _botonHistorialViajes;
	private javax.swing.JButton _botonValorar;
	private javax.swing.JButton _botonVolver;
	private javax.swing.JPanel _panelPrincipal;
	private JLabel _etiquetaSaldo;
	private int _saldoAct;
	private Controlador _ctrl;

	public InicioCliente(JFrame padre, Controlador ctrl) {
		_ventanaPadre = padre;
		_ctrl = ctrl;
		setTitle("Inicio Cliente");
		initComponents();
	}

	private void initComponents() {
		_panelPrincipal = new ImagenDeFondo();
		_botonVolver = new javax.swing.JButton();
		_botonBuscarViaje = new javax.swing.JButton();
		_botonAnularViaje = new javax.swing.JButton();
		_botonAnadirSaldo = new javax.swing.JButton();
		_botonValorar = new javax.swing.JButton();
		_botonHistorialViajes = new javax.swing.JButton();
		_etiquetaSaldo = new JLabel();

		setPreferredSize(new java.awt.Dimension(1000, 650));
		setResizable(false);

		_panelPrincipal.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "INICIO CLIENTE ",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Verdana", 1, 18), new java.awt.Color(204, 0, 51)));

		// saldo
		_etiquetaSaldo.setFont(new java.awt.Font("Verdana", 1, 18));
		_etiquetaSaldo.setText("Saldo: " + _saldoAct + "€");

		// botones
		_botonBuscarViaje.setBackground(new java.awt.Color(255, 204, 204));
		_botonBuscarViaje.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_botonBuscarViaje.setForeground(new java.awt.Color(0, 0, 0));
		_botonBuscarViaje.setText("Buscar viajes");
		_botonBuscarViaje.addActionListener((e) -> _botonBuscarViajeActionPerformed(e));

		_botonAnularViaje.setBackground(new java.awt.Color(255, 204, 204));
		_botonAnularViaje.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_botonAnularViaje.setForeground(new java.awt.Color(0, 0, 0));
		_botonAnularViaje.setText("Anular viaje");
		// _botonAnularViaje.addActionListener((e) -> metodo);

		_botonAnadirSaldo.setBackground(new java.awt.Color(255, 204, 204));
		_botonAnadirSaldo.setFont(new java.awt.Font("Verdana", 0, 18));
		_botonAnadirSaldo.setForeground(new java.awt.Color(0, 0, 0));
		_botonAnadirSaldo.setText("Añadir saldo");
		// _botonAnadirSaldo.addActionListener((e) -> metodo);

		_botonValorar.setBackground(new java.awt.Color(255, 204, 204));
		_botonValorar.setFont(new java.awt.Font("Verdana", 0, 18));
		_botonValorar.setForeground(new java.awt.Color(0, 0, 0));
		_botonValorar.setText("Valorar viaje");
		// _botonValorar.addActionListener((e) -> metodo);

		_botonHistorialViajes.setBackground(new java.awt.Color(255, 204, 204));
		_botonHistorialViajes.setFont(new java.awt.Font("Verdana", 0, 18));
		_botonHistorialViajes.setForeground(new java.awt.Color(0, 0, 0));
		_botonHistorialViajes.setText("Historial de viajes");
		// _botonHistorialViajes.addActionListener((e) -> metodo);

		_botonVolver.setBackground(new java.awt.Color(255, 204, 204));
		_botonVolver.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_botonVolver.setForeground(new java.awt.Color(0, 0, 0));
		_botonVolver.setText("Volver");
		_botonVolver.addActionListener((e) -> {
			setVisible(false);
			_ventanaPadre.setVisible(true);
		});

		javax.swing.GroupLayout _panelPrincipalLayout = new javax.swing.GroupLayout(_panelPrincipal);
		_panelPrincipal.setLayout(_panelPrincipalLayout);
		_panelPrincipalLayout.setHorizontalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addContainerGap(266, Short.MAX_VALUE).addGroup(
						_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								_panelPrincipalLayout.createSequentialGroup().addGroup(_panelPrincipalLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
										.addComponent(_botonHistorialViajes, javax.swing.GroupLayout.Alignment.LEADING,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(_botonBuscarViaje, javax.swing.GroupLayout.Alignment.LEADING,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
										.addGap(109, 109, 109)
										.addGroup(_panelPrincipalLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
												.addComponent(_botonAnularViaje, javax.swing.GroupLayout.PREFERRED_SIZE,
														243, javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(_botonAnadirSaldo, javax.swing.GroupLayout.PREFERRED_SIZE,
														243, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(185, 185, 185))
								.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
										_panelPrincipalLayout.createSequentialGroup()
												.addComponent(_botonValorar, javax.swing.GroupLayout.PREFERRED_SIZE,
														243, javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGap(354, 354, 354))
								.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, _panelPrincipalLayout
										.createSequentialGroup().addComponent(_botonVolver).addGap(430, 430, 430)))));
		_panelPrincipalLayout.setVerticalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(93, 93, 93)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_botonBuscarViaje).addComponent(_botonAnularViaje))
						.addGap(92, 92, 92)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_botonHistorialViajes).addComponent(_botonAnadirSaldo))
						.addGap(77, 77, 77).addComponent(_botonValorar)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 169, Short.MAX_VALUE)
						.addComponent(_botonVolver).addGap(62, 62, 62)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				_panelPrincipal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		pack();
		if (_ventanaPadre != null) // centrar en la ventana principal
			setLocation(_ventanaPadre.getLocation().x + _ventanaPadre.getWidth() / 2 - getWidth() / 2,
					_ventanaPadre.getLocation().y + _ventanaPadre.getHeight() / 2 - getHeight() / 2);
		setVisible(true);
	}

	private void _botonBuscarViajeActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		BuscarViajes b = new BuscarViajes(_ventanaPadre, _ctrl);
	}

	private void _botonAnularViajeActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void _botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {
		setVisible(false);
	}

	class ImagenDeFondo extends JPanel {
		@Override
		public void paint(Graphics g) {
			ImageIcon Img = new ImageIcon(("src/fondoCliente.png"));
			g.drawImage(Img.getImage(), 0, 0, getWidth(), getHeight(), this);
			setOpaque(false);
			super.paint(g);
		}
	}

}