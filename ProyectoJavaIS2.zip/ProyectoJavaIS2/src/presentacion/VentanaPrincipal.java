package presentacion;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class VentanaPrincipal extends javax.swing.JFrame {

	ImagenDeFondo fondo = new ImagenDeFondo();
	Controlador _ctrl;

	/**
	 * Creates new form VentanaPrincipal
	 */
	public VentanaPrincipal() {
		super("UCM Rails");
		setContentPane(fondo);
		pack();
		_ctrl = new Controlador();
		iniciarComponentes();
	}

	private void iniciarComponentes() {
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		GroupLayout layout = new GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 1000, Short.MAX_VALUE));
		layout.setVerticalGroup(
				layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 650, Short.MAX_VALUE));

		pack();
		setLocationRelativeTo(null); // centrar en la pantalla
		setVisible(true);
		setResizable(false);
		setContentPane(new InicioSesion(_ctrl));
		revalidate();
	}

	class ImagenDeFondo extends JPanel {
		@Override
		public void paint(Graphics g) {
			ImageIcon Img = new ImageIcon(("src/bienvenido.png"));
			g.drawImage(Img.getImage(), 0, 0, getWidth(), getHeight(), this);
			setOpaque(false);
			super.paint(g);
		}
	}
}
