package presentacion;

import java.util.Collection;
import java.util.List;

import negocio.FactoriaSA;
import negocio.FactoriaSAImp;
import negocio.TipoTren;
import negocio.TransferAdmin;
import negocio.TransferBillete;
import negocio.TransferCliente;
import negocio.TransferEstacion;
import negocio.TransferServicio;
import negocio.TransferTren;
import util.Fecha;

public class Controlador {

	TransferCliente _cliente;

	public TransferCliente getCliente() {
		return _cliente;
	}

	public boolean darDeAltaCliente(TransferCliente cliente) {
		FactoriaSA x = new FactoriaSAImp();
		_cliente = cliente;
		return x.getInstanciaSACliente().AltaCliente(cliente);
	}

	public boolean darDeAltaAdministrador(TransferAdmin admin, String validar) {
		FactoriaSA x = new FactoriaSAImp();
		return x.getInstanciaSAAdmin().AltaAdmin(admin, validar);
	}

	public int iniciarSesion(String dni, String contrasena) {
		FactoriaSA x = new FactoriaSAImp();
		_cliente = x.getInstanciaSACliente().IniciarSesion(dni, contrasena);
		if (_cliente != null) {
			return 1;
		} else if (x.getInstanciaSAAdmin().IniciarSesion(dni, contrasena) != null) {
			return 2;
		} else {
			return 0;
		}
	}

	public List<String> getListaTipoTren() {
		return TipoTren.getListaTipoTren();
	}

	public void sumarSaldo(int saldoSumado) {
		FactoriaSA x = new FactoriaSAImp();
		x.getInstanciaSACliente().anyadirDinero(_cliente, saldoSumado);
	}

	public TransferBillete buscarBillete(String idTren) {
		FactoriaSA x = new FactoriaSAImp();
		return x.getInstanciaSABillete().Buscar(idTren);
	}

	public void pagar(TransferBillete billete) {
		FactoriaSA x = new FactoriaSAImp();
		x.getInstanciaSACliente().pagar(_cliente, billete);
	}

	public List<TransferTren> buscarViaje(TransferEstacion origen, TransferEstacion destino, TipoTren t_tren,
			Fecha fecha) {
		FactoriaSA x = new FactoriaSAImp();
		return x.getInstanciaSACliente().buscarViaje(origen, destino, t_tren, fecha);
	}

	public Collection<String> getLocalidadesEstaciones() {
		FactoriaSA x = new FactoriaSAImp();
		return x.getInstanciaSAEstacion().getLocalidadesEstaciones();
	}

	public Collection<String> getNombresEstaciones() {
		FactoriaSA x = new FactoriaSAImp();
		return x.getInstanciaSAEstacion().getNombresEstaciones();
	}

	public boolean CrearServicio(TransferServicio servicio) {
		FactoriaSA factoria = new FactoriaSAImp();
		return factoria.getInstanciaSAServicio().CrearServicio(servicio);
	}
	
	public void comprarBillete(TransferBillete billete) {
		FactoriaSA factoria = new FactoriaSAImp();
		factoria.getInstanciaSABillete().ComprarBillete(_cliente, billete);
	}
}
