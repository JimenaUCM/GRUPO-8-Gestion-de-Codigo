package presentacion;

import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class DialogoAdmin extends javax.swing.JDialog {
	private JFrame _ventanaPadre;
	private javax.swing.JButton _botonSI;
	private javax.swing.JButton _botonNO;
	private javax.swing.JLabel _texto;
	private javax.swing.JPanel _panelPrincipal;
	private Controlador _ctrl;

	public DialogoAdmin(JFrame padre, Controlador ctrl) {
		super(padre, true);
		_ventanaPadre = padre;
		_ctrl = ctrl;
		setTitle("Registro");
		initComponents();
	}

	private void initComponents() {

		_panelPrincipal = new javax.swing.JPanel();
		_botonSI = new javax.swing.JButton();
		_botonNO = new javax.swing.JButton();
		_texto = new javax.swing.JLabel();

		_texto.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_texto.setText("¿Cómo desea registrarse?");

		// botones
		_botonSI.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_botonSI.setText("Admin");
		_botonSI.addActionListener((e) -> botonSIActionPerformed(e));

		_botonNO.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_botonNO.setText("Cliente");
		_botonNO.addActionListener((e) -> botonNOActionPerformed(e));

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(_panelPrincipal);
		_panelPrincipal.setLayout(jPanel2Layout);
		jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel2Layout.createSequentialGroup().addGap(123, 123, 123).addComponent(_botonSI)
						.addGap(119, 119, 119).addComponent(_botonNO)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
						.addContainerGap(88, Short.MAX_VALUE).addComponent(_texto).addGap(59, 59, 59)));
		jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
						jPanel2Layout.createSequentialGroup().addGap(40, 40, 40).addComponent(_texto)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41,
										Short.MAX_VALUE)
								.addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(_botonSI).addComponent(_botonNO))
								.addGap(39, 39, 39)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
		if (_ventanaPadre != null) // centrar en la ventana principal
			setLocation(_ventanaPadre.getLocation().x + _ventanaPadre.getWidth() / 2 - getWidth() / 2,
					_ventanaPadre.getLocation().y + _ventanaPadre.getHeight() / 2 - getHeight() / 2);
		setVisible(true);
	}

	private void botonNOActionPerformed(java.awt.event.ActionEvent evt) {
		RegistroCliente reg = new RegistroCliente(_ventanaPadre, _ctrl);
		setVisible(false);
	}

	private void botonSIActionPerformed(java.awt.event.ActionEvent evt) {
		RegistroAdministrador reg = new RegistroAdministrador(_ventanaPadre, _ctrl);
		setVisible(false);
	}

	class ImagenDeFondo extends JPanel {
		@Override
		public void paint(Graphics g) {
			ImageIcon Img = new ImageIcon(("src/fondo.png"));
			g.drawImage(Img.getImage(), 0, 0, getWidth(), getHeight(), this);
			setOpaque(false);
			super.paint(g);
		}
	}
}