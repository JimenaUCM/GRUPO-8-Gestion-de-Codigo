package presentacion;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import negocio.TransferServicio;

public class VentanaAnadirServicio extends JFrame implements Observer {

	private javax.swing.JButton _botonOK;
	private javax.swing.JLabel _nombreServicio;
	private javax.swing.JPanel _panelPrincipal;
	private javax.swing.JLabel _precioServicio;
	private javax.swing.JButton _botonCancelar;
	private javax.swing.JTextField _campoNombre;
	private javax.swing.JTextField _campoPrecio;
	private JFrame _ventanaPadre;
	private Controlador _ctrl;

	public VentanaAnadirServicio(JFrame padre, Controlador ctrl) {
		_ctrl = ctrl;
		_ventanaPadre = padre;
		setTitle("Añadir servicio");
		initComponents();
	}

	private void initComponents() {
		_panelPrincipal = new ImagenDeFondo();
		_nombreServicio = new javax.swing.JLabel();
		_precioServicio = new javax.swing.JLabel();
		_campoNombre = new javax.swing.JTextField();
		_campoPrecio = new javax.swing.JTextField();
		_botonOK = new javax.swing.JButton();
		_botonCancelar = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setPreferredSize(new java.awt.Dimension(1000, 650));
		_panelPrincipal.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Administrador - AÑADIR SERVICIO ",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Verdana", 1, 18), new java.awt.Color(0, 0, 255))); // NOI18N

		// etiquetas
		_nombreServicio.setFont(new java.awt.Font("Verdana", 0, 24));
		_nombreServicio.setText("Nombre:");

		_precioServicio.setFont(new java.awt.Font("Verdana", 0, 24));
		_precioServicio.setText("Precio:");

		// campos
		_campoNombre.setFont(new java.awt.Font("Verdana", 0, 18));
		_campoPrecio.setFont(new java.awt.Font("Verdana", 0, 18));

		// botones
		_botonOK.setFont(new java.awt.Font("Verdana", 0, 18));
		_botonOK.setText("OK");
		_botonOK.addActionListener((e) -> botonOKActionPerformed(e));

		_botonCancelar.setFont(new java.awt.Font("Verdana", 0, 18));
		_botonCancelar.setText("Cancelar");
		_botonCancelar.addActionListener((e) -> botonCancelarActionPerformed(e));

		javax.swing.GroupLayout _panelPrincipalLayout = new javax.swing.GroupLayout(_panelPrincipal);
		_panelPrincipal.setLayout(_panelPrincipalLayout);
		_panelPrincipalLayout.setHorizontalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup()
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(225, 225, 225)
										.addGroup(_panelPrincipalLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
												.addComponent(_precioServicio, javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
												.addComponent(_nombreServicio, javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
										.addGap(56, 56, 56)
										.addGroup(_panelPrincipalLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
												.addComponent(_campoNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 318,
														Short.MAX_VALUE)
												.addComponent(_campoPrecio)))
								.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(333, 333, 333)
										.addComponent(_botonOK).addGap(157, 157, 157).addComponent(_botonCancelar)))
						.addContainerGap(238, Short.MAX_VALUE)));
		_panelPrincipalLayout.setVerticalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(173, 173, 173)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(_nombreServicio).addComponent(_campoNombre,
										javax.swing.GroupLayout.PREFERRED_SIZE, 30,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(88, 88, 88)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(_precioServicio).addComponent(_campoPrecio,
										javax.swing.GroupLayout.PREFERRED_SIZE, 30,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 107, Short.MAX_VALUE)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_botonOK).addComponent(_botonCancelar))
						.addGap(100, 100, 100)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
		if (_ventanaPadre != null) // centrar en la ventana principal
			setLocation(_ventanaPadre.getLocation().x + _ventanaPadre.getWidth() / 2 - getWidth() / 2,
					_ventanaPadre.getLocation().y + _ventanaPadre.getHeight() / 2 - getHeight() / 2);
		setVisible(true);
	}

	private void botonCancelarActionPerformed(ActionEvent evt) {
		setVisible(false);
	}

	/**
	 * @author Daniel Lopez Solo de la funcion
	 */
	private void botonOKActionPerformed(ActionEvent evt) {
		try {
			TransferServicio servicio = new TransferServicio(_campoNombre.getText(),
					(int) Double.parseDouble(_campoPrecio.getText()));
			if (_ctrl.CrearServicio(servicio)) {
				JOptionPane.showMessageDialog(null, "Servicio creado con exito");
				setVisible(false);
			} else {
				Utils.showErrorMsg("No se pudo crear correctamente el servicio, vuelva a intentarlo");
			}
		} catch (Exception e) {
			Utils.showErrorMsg(e.getMessage());
		}
	}

	class ImagenDeFondo extends JPanel {
		@Override
		public void paint(Graphics g) {
			ImageIcon Img = new ImageIcon(("src/fondoAdmin.png"));
			g.drawImage(Img.getImage(), 0, 0, getWidth(), getHeight(), this);
			setOpaque(false);
			super.paint(g);
		}
	}

	@Override
	public void onServiceAdded(List<TransferServicio> servicios, TransferServicio s) {
		// TODO Auto-generated method stub
		// HACER
	}

	@Override
	public void onServiceDeleted(List<TransferServicio> servicios, TransferServicio s) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onSaldoChanged(int nuevoSaldo) {
		// TODO Auto-generated method stub

	}

}
