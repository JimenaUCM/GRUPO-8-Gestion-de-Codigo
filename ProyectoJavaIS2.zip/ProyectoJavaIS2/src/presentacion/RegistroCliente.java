package presentacion;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import negocio.TransferCliente;

import java.awt.Font;
import java.awt.event.ActionEvent;

import javax.swing.*;

public class RegistroCliente extends JDialog {

	private JFrame _ventanaPadre;
	private JPanel _panelPrincipal;
	private JLabel _etiquetaApellidos;
	private JLabel _etiquetaContrasena;
	private JLabel _etiquetaDNI;
	private JLabel _etiquetaNombre;
	private JTextField _campoApellidos;
	private JPasswordField _campoContrasena;
	private JTextField _campoDNI;
	private JTextField _campoNombre;
	private JButton _botonCancelar;
	private JButton _botonCrearCuenta;
	private Controlador _ctrl;

	public RegistroCliente(JFrame padre, Controlador ctrl) {
		_ventanaPadre = padre;
		_ctrl = ctrl;
		setTitle("Registro cliente");
		iniciarComponentes();
	}

	private void iniciarComponentes() {
		_panelPrincipal = new JPanel();
		_etiquetaNombre = new JLabel();
		_campoContrasena = new JPasswordField();
		_etiquetaDNI = new JLabel();
		_campoNombre = new JTextField();
		_etiquetaApellidos = new JLabel();
		_campoApellidos = new JTextField();
		_botonCrearCuenta = new JButton();
		_botonCancelar = new JButton();
		_etiquetaContrasena = new JLabel();
		_campoDNI = new JTextField();

		// etiquetas
		_etiquetaNombre.setFont(new Font("Verdana", 0, 18));
		_etiquetaNombre.setText("Nombre:");

		_etiquetaDNI.setFont(new Font("Verdana", 0, 18));
		_etiquetaDNI.setText("DNI:");

		_etiquetaApellidos.setFont(new Font("Verdana", 0, 18));
		_etiquetaApellidos.setText("Apellidos:");

		_etiquetaContrasena.setFont(new Font("Verdana", 0, 18));
		_etiquetaContrasena.setText("Contraseña:");

		// campos
		_campoNombre.setFont(new Font("Verdana", 0, 18));
		_campoApellidos.setFont(new Font("Verdana", 0, 18));
		_campoDNI.setFont(new Font("Verdana", 0, 18));
		_campoContrasena.setFont(new Font("Verdana", 0, 18));

		// botones
		_botonCrearCuenta.setFont(new Font("Verdana", 0, 18));
		_botonCrearCuenta.setText("Crear cuenta");
		_botonCrearCuenta.addActionListener((e) -> botonCrearCuentaActionPerformed(e));

		_botonCancelar.setFont(new Font("Verdana", 0, 18));
		_botonCancelar.setText("Cancelar");
		_botonCancelar.addActionListener((e) -> setVisible(false));

		GroupLayout jPanel1Layout = new GroupLayout(_panelPrincipal);
		_panelPrincipal.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addGap(69, 69, 69).addGroup(jPanel1Layout
						.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addGroup(jPanel1Layout.createSequentialGroup().addComponent(_botonCrearCuenta)
								.addGap(94, 94, 94).addComponent(_botonCancelar))
						.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
								.addGroup(jPanel1Layout.createSequentialGroup().addComponent(_etiquetaContrasena)
										.addGap(18, 18, 18).addComponent(_campoContrasena, GroupLayout.PREFERRED_SIZE,
												210, GroupLayout.PREFERRED_SIZE))
								.addGroup(jPanel1Layout.createSequentialGroup()
										.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
												.addComponent(_etiquetaDNI).addComponent(_etiquetaApellidos)
												.addComponent(_etiquetaNombre))
										.addGap(42, 42, 42)
										.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
												.addComponent(_campoApellidos, GroupLayout.PREFERRED_SIZE, 210,
														GroupLayout.PREFERRED_SIZE)
												.addComponent(_campoDNI, GroupLayout.PREFERRED_SIZE, 210,
														GroupLayout.PREFERRED_SIZE)
												.addComponent(_campoNombre, GroupLayout.PREFERRED_SIZE, 210,
														GroupLayout.PREFERRED_SIZE)))))
						.addGap(0, 70, Short.MAX_VALUE)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addGap(86, 86, 86)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_etiquetaNombre)
								.addComponent(_campoNombre, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(45, 45, 45)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_etiquetaApellidos)
								.addComponent(_campoApellidos, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(49, 49, 49)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_etiquetaDNI)
								.addComponent(_campoDNI, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(43, 43, 43)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_etiquetaContrasena).addComponent(_campoContrasena,
										javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 90, Short.MAX_VALUE)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_botonCrearCuenta).addComponent(_botonCancelar))
						.addGap(52, 52, 52)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
						.addComponent(_panelPrincipal, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(0, 0, Short.MAX_VALUE)));

		pack();
		if (_ventanaPadre != null) // centrar en la ventana principal
			setLocation(_ventanaPadre.getLocation().x + _ventanaPadre.getWidth() / 2 - getWidth() / 2,
					_ventanaPadre.getLocation().y + _ventanaPadre.getHeight() / 2 - getHeight() / 2);
		setVisible(true);
	}

	private void botonCrearCuentaActionPerformed(ActionEvent evt) {
		try {
			char[] contrasena = _campoContrasena.getPassword();
			String pass = new String(contrasena);
			TransferCliente cliente = new TransferCliente(_campoNombre.getText(), _campoApellidos.getText(),
					_campoDNI.getText(), pass, 0);
			if (!_ctrl.darDeAltaCliente(cliente)) {
				throw new IllegalArgumentException("La cuenta no se pudo crear por un error");
			}
			JOptionPane.showMessageDialog(null, "Cuenta creada con exito");
			setVisible(false);
		} catch (Exception e) { // se lanza excepcion si los datos son incorrectos
			Utils.showErrorMsg(e.getMessage());
		}
	}
}