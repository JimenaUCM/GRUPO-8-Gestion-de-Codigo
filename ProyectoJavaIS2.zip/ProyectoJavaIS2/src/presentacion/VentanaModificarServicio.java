package presentacion;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

import negocio.TransferServicio;

public class VentanaModificarServicio extends JFrame implements Observer {

	private JFrame _ventanaPadre;
	private javax.swing.JButton _botonCancelar;
	private javax.swing.JButton _botonOK;
	private javax.swing.JTextField _campoPrecio;
	private javax.swing.JLabel _nombreServicio;
	private javax.swing.JPanel _panelPrincipal;
	private javax.swing.JLabel _precioServicio;
	private javax.swing.JComboBox<String> _servicios;
	private javax.swing.JLabel _texto;
	private int _opcionSeleccionada;
	private Controlador _ctrl;

	public VentanaModificarServicio(JFrame padre, Controlador ctrl) {
		_ventanaPadre = padre;
		_ctrl = ctrl;
		setTitle("Añadir servicio");
		initComponents();
	}

	private void initComponents() {
		_panelPrincipal = new ImagenDeFondo();
		_nombreServicio = new javax.swing.JLabel();
		_precioServicio = new javax.swing.JLabel();
		_campoPrecio = new javax.swing.JTextField();
		_servicios = new javax.swing.JComboBox<>();
		_texto = new javax.swing.JLabel();
		_botonOK = new javax.swing.JButton();
		_botonCancelar = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setPreferredSize(new java.awt.Dimension(1000, 650));
		_panelPrincipal.setBorder(javax.swing.BorderFactory.createTitledBorder(null,
				"Administrador - MODIFICAR SERVICIO ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 1, 18),
				new java.awt.Color(0, 0, 255)));

		_texto.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
		_texto.setText(
				"Seleccione el nombre del servicio que desea modificar y a continuación inserte un nuevo precio");

		// etiquetas
		_nombreServicio.setFont(new java.awt.Font("Verdana", 0, 24)); // NOI18N
		_nombreServicio.setText("Nombre:");

		_precioServicio.setFont(new java.awt.Font("Verdana", 0, 24)); // NOI18N
		_precioServicio.setText("Precio:");

		// comboBox
		_servicios.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_servicios.setModel( // cambiar el array ese
				new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
		_servicios.addActionListener((e) -> _opcionSeleccionada = _servicios.getSelectedIndex());

		// botones
		_botonOK.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_botonOK.setText("OK");
		_botonOK.addActionListener((e) -> _botonOKActionPerformed(e));

		_botonCancelar.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_botonCancelar.setText("Cancelar");
		_botonCancelar.addActionListener((e) -> _botonCancelarActionPerformed(e));

		javax.swing.GroupLayout _panelPrincipalLayout = new javax.swing.GroupLayout(_panelPrincipal);
		_panelPrincipal.setLayout(_panelPrincipalLayout);
		_panelPrincipalLayout.setHorizontalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(165, 165, 165)
						.addComponent(_nombreServicio)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(0, 125, Short.MAX_VALUE)
										.addComponent(_botonOK).addGap(123, 123, 123).addComponent(_botonCancelar))
								.addGroup(_panelPrincipalLayout.createSequentialGroup()
										.addComponent(_servicios, 0, javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addGap(52, 52, 52).addComponent(_precioServicio)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addComponent(_campoPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 118,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(186, 186, 186))
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(154, 154, 154).addComponent(_texto)
						.addGap(0, 0, Short.MAX_VALUE)));
		_panelPrincipalLayout.setVerticalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(93, 93, 93).addComponent(_texto)
						.addGap(86, 86, 86)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(_panelPrincipalLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
										.addComponent(_campoPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(_precioServicio))
								.addComponent(_servicios, javax.swing.GroupLayout.Alignment.TRAILING,
										javax.swing.GroupLayout.PREFERRED_SIZE, 34,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(_nombreServicio, javax.swing.GroupLayout.Alignment.TRAILING))
						.addGap(147, 147, 147)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_botonOK).addComponent(_botonCancelar))
						.addContainerGap(160, Short.MAX_VALUE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
		if (_ventanaPadre != null) // centrar en la ventana principal
			setLocation(_ventanaPadre.getLocation().x + _ventanaPadre.getWidth() / 2 - getWidth() / 2,
					_ventanaPadre.getLocation().y + _ventanaPadre.getHeight() / 2 - getHeight() / 2);
		setVisible(true);
	}

	private void _botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {
		setVisible(false);
	}

	private void _botonOKActionPerformed(java.awt.event.ActionEvent evt) {
		// cosas, hacer que se cambie el precio en la BD
		setVisible(false);
	}

	/*
	 * public String[] getServicios() { List<String> servicios = new
	 * ArrayList<String>(); //obtener los servicios que hay en la BD
	 * 
	 * return servicios; }
	 */

	class ImagenDeFondo extends JPanel {
		@Override
		public void paint(Graphics g) {
			ImageIcon Img = new ImageIcon(("src/fondoAdmin.png"));
			g.drawImage(Img.getImage(), 0, 0, getWidth(), getHeight(), this);
			setOpaque(false);
			super.paint(g);
		}
	}

	@Override
	public void onServiceAdded(List<TransferServicio> servicios, TransferServicio s) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onServiceDeleted(List<TransferServicio> servicios, TransferServicio s) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onSaldoChanged(int nuevoSaldo) {
		// TODO Auto-generated method stub

	}

}