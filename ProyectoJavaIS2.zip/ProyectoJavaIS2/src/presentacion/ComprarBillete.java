package presentacion;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import negocio.TransferBillete;
import negocio.TransferCliente;
import negocio.TransferTren;

public class ComprarBillete extends JPanel {
	String[] _header = { "Id", "Ciudad origen", "Estación origen", "Ciudad destino", "Estación destino", "Tipo de tren",
			"precio", "horario" };
	List<TransferTren> _listaTrenes;
	private DefaultTableModel _dataTableModel;
	private JComboBox<Integer> _opcionesBilletes;
	private int _opcionSeleccionada;
	Controlador _ctrl;
	JFrame _ventanaPadre;

	public ComprarBillete(Controlador ctrl, List<TransferTren> listaTrenes, JFrame ventanaPadre) {
		_listaTrenes = listaTrenes;
		_ctrl = ctrl;
		_ventanaPadre = ventanaPadre;
		initComponents();
	}

	public void initComponents() {
		setPreferredSize(new Dimension(1000, 650));

		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		mainPanel.setPreferredSize(new Dimension(1000, 650));

		_dataTableModel = new DefaultTableModel();
		_dataTableModel.setColumnIdentifiers(_header);

		JTable table = new JTable(_dataTableModel) {
			private static final long serialVersionUID = 1L;

			// we override prepareRenderer to resize columns to fit to content
			@Override
			public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
				Component component = super.prepareRenderer(renderer, row, column);
				int rendererWidth = component.getPreferredSize().width;
				TableColumn tableColumn = getColumnModel().getColumn(column);
				tableColumn.setPreferredWidth(
						Math.max(rendererWidth + getIntercellSpacing().width, tableColumn.getPreferredWidth()));
				return component;
			}
		};

		JScrollPane scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); // crear un JScrollPane que contenga la tabla
		mainPanel.add(scrollPane); // agregar el JScrollPane al panel

		updateDataTableModel(); // rellenar tabla
		addComboBox(mainPanel); // añadir el combobox
		addButtons(mainPanel); // añadir botones

		Frame parent = (Frame) this.getParent();
		if (this.getParent() != null) // centrar
			setLocation(parent.getLocation().x + parent.getWidth() / 2 - getWidth() / 2,
					parent.getLocation().y + parent.getHeight() / 2 - getHeight() / 2);

		this.add(mainPanel);
	}

	public void addButtons(JPanel mainPanel) { // Añadir botones al panel
		JPanel buttonPanel = new JPanel();
		buttonPanel.setAlignmentX(CENTER_ALIGNMENT);

		// Comprar
		JButton botonComprar = new JButton("Comprar");
		botonComprar.addActionListener((e) -> {
			try {
				TransferCliente cliente = _ctrl.getCliente();
				String idTren = _listaTrenes.get(_opcionSeleccionada).getId();
				TransferBillete billete = _ctrl.buscarBillete(idTren);
				_ctrl.comprarBillete(billete);
				JOptionPane.showMessageDialog(null, "Compra realizada con exito");
				_ventanaPadre.setVisible(false);
			} catch (Exception e1) { // Por si no tiene suficiente dinero, etc
				Utils.showErrorMsg(e1.getMessage());
			}
		});
		buttonPanel.add(botonComprar);

		// Volver, vuelve a inicioCliente en teoría, porque esto es un panel
		JButton botonVolver = new JButton("Volver");
		botonVolver.addActionListener((e) -> {
			_ventanaPadre.setVisible(false);
		});
		buttonPanel.add(botonVolver);

		mainPanel.add(buttonPanel);
	}

	public void addComboBox(JPanel mainPanel) {
		JPanel comboBoxPanel = new JPanel();
		comboBoxPanel.setAlignmentX(CENTER_ALIGNMENT);
		_opcionesBilletes = new JComboBox<>();
		_opcionesBilletes.setFont(new java.awt.Font("Verdana", 0, 18));
		_opcionesBilletes.setModel(new javax.swing.DefaultComboBoxModel<>(numBilletes()));
		_opcionesBilletes.addActionListener((e) -> _opcionSeleccionada = _opcionesBilletes.getSelectedIndex() + 1);

		comboBoxPanel.add(_opcionesBilletes);
		mainPanel.add(comboBoxPanel);
	}

	public void updateDataTableModel() { // Actualizar la tabla de datos de la ley seleccionada
		_dataTableModel.setRowCount(0); // eliminar filas
		for (int i = 0; i < _listaTrenes.size(); i++) { // poner filas correspondientes a la ley de fuerza
			int idInt = i + 1;
			String id = String.valueOf(idInt);
			String ciuOrigen = _listaTrenes.get(i).getRuta().getEstacionOrigen().getLocalidad();
			String estOrigen = _listaTrenes.get(i).getRuta().getEstacionOrigen().getNombre();
			String ciuDestino = _listaTrenes.get(i).getRuta().getEstacionDestino().getLocalidad();
			String estDestino = _listaTrenes.get(i).getRuta().getEstacionDestino().getNombre();
			String tipoTren = _listaTrenes.get(i).getTipoTren().name();
			double p = _listaTrenes.get(i).getRuta().getPrecio();
			String precio = Double.toString(p);
			String horario = _listaTrenes.get(i).getHoraSalida().toString();

			_dataTableModel.addRow(
					new String[] { id, ciuOrigen, estOrigen, ciuDestino, estDestino, tipoTren, precio, horario });
		}
		_dataTableModel.fireTableDataChanged(); // actualizar la tabla
	}

	private Integer[] numBilletes() {
		Integer[] billetes = new Integer[_listaTrenes.size()];
		for (Integer i = 1; i <= _listaTrenes.size(); i++) {
			billetes[i - 1] = i;
		}
		return billetes;
	}

	class ImagenDeFondo extends JPanel {
		@Override
		public void paint(Graphics g) {
			ImageIcon Img = new ImageIcon(("src/fondoCliente.png"));
			g.drawImage(Img.getImage(), 0, 0, getWidth(), getHeight(), this);
			setOpaque(false);
			super.paint(g);
		}
	}
}