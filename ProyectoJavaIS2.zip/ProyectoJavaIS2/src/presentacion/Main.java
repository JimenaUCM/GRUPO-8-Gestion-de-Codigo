package presentacion;

import java.lang.reflect.InvocationTargetException;

import javax.swing.SwingUtilities;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			SwingUtilities.invokeAndWait(() -> new VentanaPrincipal());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}