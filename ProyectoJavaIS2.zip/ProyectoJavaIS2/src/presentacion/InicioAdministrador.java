package presentacion;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class InicioAdministrador extends JFrame {

	private JFrame _ventanaPadre;
	private javax.swing.JButton _botonVolver;
	private javax.swing.JButton _botonOK;
	private javax.swing.JComboBox<String> _opcionesAdmin;
	private javax.swing.JPanel _panelPrincipal;
	private javax.swing.JLabel _texto;
	private int _opcionSeleccionada;
	private Controlador _ctrl;

	public InicioAdministrador(JFrame padre, Controlador ctrl) {
		_ventanaPadre = padre;
		_ctrl = ctrl;
		setTitle("Inicio Administrador");
		initComponents();
	}

	private void initComponents() {
		_panelPrincipal = new ImagenDeFondo();
		_opcionesAdmin = new javax.swing.JComboBox<>();
		_texto = new javax.swing.JLabel();
		_botonOK = new javax.swing.JButton();
		_botonVolver = new javax.swing.JButton();

		// setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setPreferredSize(new java.awt.Dimension(1000, 650));
		_panelPrincipal.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "INICIO ADMINISTRADOR ",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Verdana", 1, 18), new java.awt.Color(0, 0, 255))); // NOI18N

		this.setResizable(false);

		// comboBox
		_opcionesAdmin.setFont(new java.awt.Font("Verdana", 0, 18));
		_opcionesAdmin.setModel(new javax.swing.DefaultComboBoxModel<>(initOpciones()));
		_opcionesAdmin.addActionListener((e) -> _opcionSeleccionada = _opcionesAdmin.getSelectedIndex());

		// texto
		_texto.setFont(new java.awt.Font("Verdana", 0, 18));
		_texto.setText("Seleccione la acción que desea realizar");

		// botones
		_botonOK.setFont(new java.awt.Font("Verdana", 0, 18));
		_botonOK.setText("OK");
		_botonOK.addActionListener((e) -> _botonOKActionPerformed(e));

		_botonVolver.setFont(new java.awt.Font("Verdana", 0, 18));
		_botonVolver.setText("Volver");
		_botonVolver.addActionListener((e) -> _botonCancelarActionPerformed(e));

		javax.swing.GroupLayout _panelPrincipalLayout = new javax.swing.GroupLayout(_panelPrincipal);
		_panelPrincipal.setLayout(_panelPrincipalLayout);
		_panelPrincipalLayout.setHorizontalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addContainerGap(291, Short.MAX_VALUE)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
										_panelPrincipalLayout.createSequentialGroup().addComponent(_botonOK)
												.addGap(141, 141, 141).addComponent(_botonVolver).addGap(316, 316, 316))
								.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
										_panelPrincipalLayout.createSequentialGroup().addComponent(_texto).addGap(304,
												304, 304))
								.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
										_panelPrincipalLayout.createSequentialGroup()
												.addComponent(_opcionesAdmin, javax.swing.GroupLayout.PREFERRED_SIZE,
														397, javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGap(276, 276, 276)))));
		_panelPrincipalLayout.setVerticalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(96, 96, 96).addComponent(_texto)
						.addGap(75, 75, 75)
						.addComponent(_opcionesAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(172, 172, 172)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_botonOK).addComponent(_botonVolver))
						.addContainerGap(184, Short.MAX_VALUE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				_panelPrincipal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
		if (_ventanaPadre != null) // centrar en la ventana principal
			setLocation(_ventanaPadre.getLocation().x + _ventanaPadre.getWidth() / 2 - getWidth() / 2,
					_ventanaPadre.getLocation().y + _ventanaPadre.getHeight() / 2 - getHeight() / 2);
		setVisible(true);
	}

	private String[] initOpciones() {
		List<String> opciones = new ArrayList<String>();
		opciones.add("Anadir servicio");
		opciones.add("Modificar servicio");
		opciones.add("Eliminar servicio");
		opciones.add("Anadir ruta");
		opciones.add("Eliminar ruta");
		opciones.add("Anadir tren");
		opciones.add("Modificar tren");
		opciones.add("Eliminar tren");
		opciones.add("Anadir estacion");
		opciones.add("Eliminar estacion");
		return opciones.toArray(new String[0]);
	}

	private void _botonCancelarActionPerformed(ActionEvent e) {
		setVisible(false);
		_ventanaPadre.setVisible(true);
	}

	private void _botonOKActionPerformed(java.awt.event.ActionEvent evt) {
		switch (_opcionSeleccionada) {
		case 0: // añadir servicio
			VentanaAnadirServicio anadirServicio = new VentanaAnadirServicio(this, _ctrl);
			break;
		case 1: // modificar servicio
			VentanaModificarServicio mofificarServicio = new VentanaModificarServicio(this, _ctrl);
			break;
		case 2: // eliminar servicio
			// abrir nueva ventana
			break;
		case 3: // añadir ruta
			// abrir nueva ventana
			break;
		case 4: // eliminar ruta
			// abrir nueva ventana
			break;
		case 5: // añadir tren
			// abrir nueva ventana
			break;
		case 6: // modificar tren
			// abrir nueva ventana
			break;
		case 7: // eliminar tren
			// abrir nueva ventana
			break;
		case 8: // añadir estacion
			// abrir nueva ventana
			break;
		case 9: // eliminar estacion
			// abrir nueva ventana
			break;
		}
	}

	class ImagenDeFondo extends JPanel {
		@Override
		public void paint(Graphics g) {
			ImageIcon Img = new ImageIcon(("src/fondoAdmin.png"));
			g.drawImage(Img.getImage(), 0, 0, getWidth(), getHeight(), this);
			setOpaque(false);
			super.paint(g);
		}
	}

}
