package presentacion;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.RootPaneContainer;

import com.mxrck.autocompleter.AutoCompleter;
import com.mxrck.autocompleter.TextAutoCompleter;

import negocio.TipoTren;
import negocio.TransferEstacion;
import negocio.TransferTren;
import util.Fecha;

/**
 *
 * @author salma
 */
public class BuscarViajes extends javax.swing.JFrame {
	public static final int[] DIAS_MES = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }; // El numero de dias que
	private javax.swing.JComboBox<Integer> _anyos;
	private javax.swing.JButton _botonBuscar;
	private javax.swing.JButton _botonCancelar;
	
	private javax.swing.JTextField _campoCiuDestino;
	private TextAutoCompleter _campoCiuDestinoAuto;
	private javax.swing.JTextField _campoCiuOrigen;
	private TextAutoCompleter _campoCiuOrigenAuto;
	private javax.swing.JTextField _campoEstDestino;
	private TextAutoCompleter _campoEstDestinoAuto;
	private javax.swing.JTextField _campoEstOrigen;
	private TextAutoCompleter _campoEstOrigenAuto;
	private javax.swing.JComboBox<Integer> _dias;
	private javax.swing.JLabel _etiquetaCiuDestino;
	private javax.swing.JLabel _etiquetaCiuOrigen;
	private javax.swing.JLabel _etiquetaEstDestino;
	private javax.swing.JLabel _etiquetaEstOrigen;
	private javax.swing.JLabel _etiquetaFecha;
	private javax.swing.JLabel _etiquetaTipoTren;
	private javax.swing.JComboBox<Integer> _meses;
	private javax.swing.JComboBox<String> _opcionesTren;
	private javax.swing.JPanel _panelPrincipal;
	private JFrame _ventanaPadre;
	private Controlador _ctrl;

	public BuscarViajes(JFrame padre, Controlador ctrl) {
		_ventanaPadre = padre;
		_ctrl = ctrl;
		initComponents();
	}

	private void initComponents() {

		_panelPrincipal = new ImagenDeFondo();
		_etiquetaEstDestino = new javax.swing.JLabel();
		_etiquetaCiuDestino = new javax.swing.JLabel();
		_etiquetaCiuOrigen = new javax.swing.JLabel();
		_etiquetaEstOrigen = new javax.swing.JLabel();
		_dias = new javax.swing.JComboBox<>();
		_etiquetaFecha = new javax.swing.JLabel();
		_anyos = new javax.swing.JComboBox<>();
		_meses = new javax.swing.JComboBox<>();
		_botonBuscar = new javax.swing.JButton();
		_botonCancelar = new javax.swing.JButton();
		_etiquetaTipoTren = new javax.swing.JLabel();
		_campoCiuDestino = new javax.swing.JTextField();
		_campoCiuDestinoAuto = new TextAutoCompleter(_campoCiuDestino);
		_campoEstOrigen = new javax.swing.JTextField();
		_campoEstOrigenAuto = new TextAutoCompleter(_campoEstOrigen);
		_campoEstDestino = new javax.swing.JTextField();
		_campoEstDestinoAuto = new TextAutoCompleter(_campoEstDestino);
		_campoCiuOrigen = new javax.swing.JTextField();
		_campoCiuOrigenAuto = new TextAutoCompleter(_campoCiuOrigen);
		_opcionesTren = new javax.swing.JComboBox<>();
		
		Collection<String> nombresEstaciones = _ctrl.getNombresEstaciones();
		for (String nombre : nombresEstaciones) {
			_campoEstDestinoAuto.addItem(nombre);
			_campoEstOrigenAuto.addItem(nombre);
		}
		
		Collection<String> localidades = _ctrl.getLocalidadesEstaciones();
		for (String localidad : localidades) {			
			_campoCiuDestinoAuto.addItem(localidad);
			_campoCiuOrigenAuto.addItem(localidad);
		}

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		_panelPrincipal.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "BUSCAR VIAJES ",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Verdana", 1, 18), new java.awt.Color(204, 0, 51))); // NOI18N

		// etiquetas
		_etiquetaEstDestino.setFont(new java.awt.Font("Verdana", 0, 22)); // NOI18N
		_etiquetaEstDestino.setText("Estación destino:");

		_etiquetaCiuDestino.setFont(new java.awt.Font("Verdana", 0, 22)); // NOI18N
		_etiquetaCiuDestino.setText("Ciudad destino:");

		_etiquetaCiuOrigen.setFont(new java.awt.Font("Verdana", 0, 22)); // NOI18N
		_etiquetaCiuOrigen.setText("Ciudad origen:");

		_etiquetaEstOrigen.setFont(new java.awt.Font("Verdana", 0, 22)); // NOI18N
		_etiquetaEstOrigen.setText("Estación origen:");

		_etiquetaFecha.setFont(new java.awt.Font("Verdana", 0, 22)); // NOI18N
		_etiquetaFecha.setText("Fecha:");

		_etiquetaTipoTren.setFont(new java.awt.Font("Verdana", 0, 22)); // NOI18N
		_etiquetaTipoTren.setText("Tipo de tren:");

		// campos
		_campoCiuDestino.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_campoEstOrigen.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_campoEstDestino.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_campoCiuOrigen.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N

		// comoBoxes
		_opcionesTren.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		List<String> tipos = _ctrl.getListaTipoTren();
		String[] array = tipos.toArray(String[]::new);
		_opcionesTren.setModel(new javax.swing.DefaultComboBoxModel<>(array));

		_anyos.setModel(new javax.swing.DefaultComboBoxModel<>(new Integer[] { 2023 }));

		_meses.setModel(
				new javax.swing.DefaultComboBoxModel<>(new Integer[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 }));
		_meses.addActionListener((e) -> mesesActionPerformed(e));

		// botones
		_botonBuscar.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_botonBuscar.setText("Buscar");
		_botonBuscar.setForeground(new java.awt.Color(0, 0, 0));
		_botonBuscar.addActionListener((e) -> botonBuscarActionPerformed(e));

		_botonCancelar.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
		_botonCancelar.setText("Cancelar");
		_botonCancelar.setForeground(new java.awt.Color(0, 0, 0));
		_botonCancelar.addActionListener((e) -> _botonCancelarActionPerformed(e));

		javax.swing.GroupLayout _panelPrincipalLayout = new javax.swing.GroupLayout(_panelPrincipal);
		_panelPrincipal.setLayout(_panelPrincipalLayout);
		_panelPrincipalLayout.setHorizontalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(128, 128, 128)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(_etiquetaCiuDestino).addComponent(_etiquetaCiuOrigen))
						.addGap(18, 18, 18)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addComponent(_campoCiuDestino, javax.swing.GroupLayout.PREFERRED_SIZE, 198,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(_campoCiuOrigen, javax.swing.GroupLayout.PREFERRED_SIZE, 198,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 96, Short.MAX_VALUE)
						.addGroup(
								_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(_panelPrincipalLayout.createSequentialGroup()
												.addComponent(_etiquetaEstDestino)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(_campoEstDestino, javax.swing.GroupLayout.PREFERRED_SIZE,
														198, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(_panelPrincipalLayout.createSequentialGroup()
												.addComponent(_etiquetaEstOrigen).addGap(18, 18, 18)
												.addComponent(_campoEstOrigen, javax.swing.GroupLayout.PREFERRED_SIZE,
														198, javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addGap(110, 110, 110))
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(215, 215, 215)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(_panelPrincipalLayout.createSequentialGroup().addComponent(_etiquetaTipoTren)
										.addGap(70, 70, 70).addComponent(_opcionesTren,
												javax.swing.GroupLayout.PREFERRED_SIZE, 269,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(_panelPrincipalLayout.createSequentialGroup().addComponent(_etiquetaFecha)
										.addGap(87, 87, 87)
										.addGroup(_panelPrincipalLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addGroup(_panelPrincipalLayout.createSequentialGroup()
														.addComponent(_botonBuscar).addGap(185, 185, 185)
														.addComponent(_botonCancelar))
												.addGroup(_panelPrincipalLayout.createSequentialGroup()
														.addComponent(_dias, javax.swing.GroupLayout.PREFERRED_SIZE,
																105, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addGap(112, 112, 112)
														.addComponent(_meses, javax.swing.GroupLayout.PREFERRED_SIZE,
																105, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addGap(89, 89, 89)
														.addComponent(_anyos, javax.swing.GroupLayout.PREFERRED_SIZE,
																105, javax.swing.GroupLayout.PREFERRED_SIZE)))))
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		_panelPrincipalLayout.setVerticalGroup(_panelPrincipalLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(_panelPrincipalLayout.createSequentialGroup().addGap(64, 64, 64)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_etiquetaEstOrigen).addComponent(_etiquetaCiuOrigen)
								.addComponent(_campoEstOrigen, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(_campoCiuOrigen, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(70, 70, 70)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_etiquetaCiuDestino).addComponent(_etiquetaEstDestino)
								.addComponent(_campoCiuDestino, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(_campoEstDestino, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(68, 68, 68)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_meses, javax.swing.GroupLayout.PREFERRED_SIZE, 31,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(_dias, javax.swing.GroupLayout.PREFERRED_SIZE, 31,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(_anyos, javax.swing.GroupLayout.PREFERRED_SIZE, 31,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(_etiquetaFecha))
						.addGap(43, 43, 43)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(_etiquetaTipoTren).addComponent(_opcionesTren,
										javax.swing.GroupLayout.PREFERRED_SIZE, 36,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 135, Short.MAX_VALUE)
						.addGroup(_panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(_botonCancelar).addComponent(_botonBuscar))
						.addGap(78, 78, 78)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				_panelPrincipal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(_panelPrincipal,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
		if (_ventanaPadre != null) // centrar en la ventana principal
			setLocation(_ventanaPadre.getLocation().x + _ventanaPadre.getWidth() / 2 - getWidth() / 2,
					_ventanaPadre.getLocation().y + _ventanaPadre.getHeight() / 2 - getHeight() / 2);
		setVisible(true);
	}

	private void mesesActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		_dias.setModel(new javax.swing.DefaultComboBoxModel<>(listaDias((int) _meses.getSelectedItem())));
	}

	private void _botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {
		setVisible(false);
	}

	private void botonBuscarActionPerformed(java.awt.event.ActionEvent evt) {
		try {
			TransferEstacion origen = new TransferEstacion(_campoEstOrigen.getText(), _campoCiuOrigen.getText());
			TransferEstacion destino = new TransferEstacion(_campoEstDestino.getText(), _campoCiuDestino.getText());
			Fecha fecha = new Fecha((int) _dias.getSelectedItem(), (int) _meses.getSelectedItem(),
					(int) _anyos.getSelectedItem());
			TipoTren tipoTren;
			if (_opcionesTren.getSelectedItem().equals("AltaVelocidad")) {
				tipoTren = TipoTren.AltaVelocidad;
			} else if (_opcionesTren.getSelectedItem().equals("Estandar")) {
				tipoTren = TipoTren.Estandar;
			} else {
				tipoTren = TipoTren.Economico;
			}

			List<TransferTren> listaTrenes = _ctrl.buscarViaje(origen, destino, tipoTren, fecha);
			// se cambia de panel
			this.setContentPane(new ComprarBillete(_ctrl, listaTrenes, this));
			this.revalidate();

			// el panel nuevo muestra los billetes
			// en formato tabla, cada fila es un Transfer tren con todos los datos del
			// billete, para elegir uno, se pone un comboBox con numeros que correponden a
			// las casillas de de ese array de tRnsferTren, y se invoca a comprar

		} catch (Exception e) {
			Utils.showErrorMsg(e.getMessage());
		}
	}

	private Integer[] listaDias(int mes) {
		Integer[] dias = new Integer[DIAS_MES[mes - 1]];
		for (Integer i = 1; i <= DIAS_MES[mes - 1]; i++) {
			dias[i - 1] = i;
		}
		return dias;
	}

	class ImagenDeFondo extends JPanel {
		@Override
		public void paint(Graphics g) {
			ImageIcon Img = new ImageIcon(("src/fondoCliente.png"));
			g.drawImage(Img.getImage(), 0, 0, getWidth(), getHeight(), this);
			setOpaque(false);
			super.paint(g);
		}
	}
}
