package integracion;

import java.util.Collection;

import negocio.TransferCliente;

public interface DAOCliente {

	public boolean darAlta(TransferCliente cliente);

	public int darAlta(Collection<TransferCliente> usuario);

	public TransferCliente buscar(String dni);

	public boolean darBaja(String dni);

	public int darBaja(Collection<String> dnis);

	public boolean actualizar(TransferCliente cliente);

	public int actualizar(Collection<TransferCliente> clientes);
}