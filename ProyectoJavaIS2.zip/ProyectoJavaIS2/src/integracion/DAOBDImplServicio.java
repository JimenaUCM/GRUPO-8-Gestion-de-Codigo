package integracion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import negocio.TransferBillete;
import negocio.TransferServicio;

public class DAOBDImplServicio implements DAOServicio {

	private static final String _QUERY_BUSCAR = "SELECT * FROM servicio WHERE nombre = ?";
	private static final String _QUERY_ALTA = "INSERT INTO servicio (nombre, precio) VALUES (?,?)";
	private static final String _QUERY_BAJA = "DELETE FROM servicio WHERE nombre  = ?";
	private static final String _QUERY_UPDATE = "UPDATE servicio SET precio = ? WHERE nombre = ?";
	private static final String _QUERY_BUSCAR_LISTA = "SELECT * FROM servicio";


	private static DAOBDImplServicio _daoServicio = null;
	private Connection _connection;

	DAOBDImplServicio(Connection connection) {
		_connection = connection;
	}

	static public DAOBDImplServicio getInstance(Connection connection) {
		if (_daoServicio == null)
			_daoServicio = new DAOBDImplServicio(connection);
		return _daoServicio;
	}

	@Override
	public boolean darAlta(TransferServicio servicio) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_ALTA)) {
			// Dar valores a parametro de busqueda
			st.setString(1, servicio.get_nombre());
			st.setInt(2, servicio.get_precio());
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			return filasAfectadas == 1;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public int darAlta(Collection<TransferServicio> servicios) {
		int filasAfectadas = 0;
		for (TransferServicio servicio : servicios) {
			if (darAlta(servicio)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;
	}

	@Override
	public TransferServicio buscar(String nombre) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BUSCAR)) {
			// Dar valores a parametro de busqueda
			st.setString(1, nombre);
			// Ejecuta la query
			ResultSet rs = st.executeQuery();
			return get_nextServicio(rs);
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean darBaja(String nombre) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BAJA)) {
			// Dar valores a parametro de busqueda
			st.setString(1, nombre);
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			return filasAfectadas == 1;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public int darBaja(Collection<String> nombres) {
		int filasAfectadas = 0;
		for (String nombre : nombres) {
			if (darBaja(nombre)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;
	}

	@Override
	public boolean actualizar(TransferServicio servicio) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_UPDATE)) {
			// Dar valores a parametro de busqueda
			st.setInt(1, servicio.get_precio());
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			return filasAfectadas == 1;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public int actualizar(Collection<TransferServicio> servicios) {
		int filasAfectadas = 0;
		for (TransferServicio servicio : servicios) {
			if (actualizar(servicio)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;
	}

	public TransferServicio get_nextServicio(ResultSet rs) {
		TransferServicio servicio = null;
		try {
			if (rs.next()) {
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				servicio = new TransferServicio(nombre, precio);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return servicio;
	}
	
	public Collection<TransferServicio> buscarListaServicios(){
		Collection<TransferServicio> servicios = new ArrayList<TransferServicio>();
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BUSCAR_LISTA)) {
			// Ejecuta la query
			ResultSet rs = st.executeQuery();
			while (rs.next())
				servicios.add(get_nextServicio(rs));
			return new ArrayList<TransferServicio>();
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return null;
		}
		
	}

}
