package integracion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import negocio.TransferEstacion;
import negocio.TransferRuta;
import negocio.TransferServicio;

public class DAOBDImplRuta implements DAORuta{
	
	private static final String _QUERY_BUSCAR = "SELECT * FROM ruta WHERE nombre = ?";
	private static final String _QUERY_ALTA = "INSERT INTO ruta (nombre, precio, estacioorigen, estaciondestino, localidadorigen, localidaddestino, duracionminutos) VALUES (?,?,?,?,?,?,?)";
	private static final String _QUERY_BAJA = "DELETE FROM ruta WHERE nombre = ?";

	
	private static DAOBDImplRuta _daoRuta = null;
	private DAOEstacion _daoEstacion;
	private Connection _connection;

	DAOBDImplRuta(Connection connection, DAOEstacion daoEstacion) {
		_connection = connection;
		_daoEstacion = daoEstacion;
	}

	static public DAOBDImplRuta getInstance(Connection connection, DAOEstacion daoEstacion) {
		if (_daoRuta == null)
			_daoRuta = new DAOBDImplRuta(connection, daoEstacion);
		return _daoRuta;
	}
	
	@Override
	public boolean darAlta(TransferRuta ruta) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_ALTA)) {
			// Dar valores a parametro de busqueda
			st.setString(1, ruta.getNombre());
			st.setDouble(2, ruta.getPrecio());
			st.setString(3, ruta.getEstacionOrigen().getNombre());
			st.setString(4, ruta.getEstacionDestino().getNombre());
			st.setString(5, ruta.getEstacionOrigen().getLocalidad());
			st.setString(6, ruta.getEstacionDestino().getLocalidad());
			st.setInt(7, ruta.getDuracion());

			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			return filasAfectadas == 1;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public int darAlta(Collection<TransferRuta> rutas) {
		int filasAfectadas = 0;
		for (TransferRuta ruta : rutas) {
			if (darAlta(ruta)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;
	}

	@Override
	public TransferRuta buscar(String nombre) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BUSCAR)) {
			// Dar valores a parametro de busqueda
			st.setString(1, nombre);
			// Ejecuta la query
			ResultSet rs = st.executeQuery();
			return get_nextRuta(rs);
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean darBaja(String nombre) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BAJA)) {
			// Dar valores a parametro de busqueda
			st.setString(1, nombre);
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			return filasAfectadas == 1;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public int darBaja(Collection<String> nombres) {
		int filasAfectadas = 0;
		for (String nombre : nombres) {
			if (darBaja(nombre)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;	
	}
	
	public TransferRuta get_nextRuta(ResultSet rs) {
		TransferRuta ruta = null;
		try {
			if (rs.next()) {
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String nombreEstacionOrigen = rs.getString("estacionorigen");
				String nombreEstacionDestino = rs.getString("estaciondestino");
				String localidadEstacionOrigen = rs.getString("localidadorigen");
				String localidadEstacionDestino = rs.getString("localidaddestino");
				TransferEstacion estacionOrigen = _daoEstacion.buscar(nombreEstacionOrigen, localidadEstacionOrigen);
				TransferEstacion estacionDestino = _daoEstacion.buscar(nombreEstacionDestino, localidadEstacionDestino);
				int duracion = rs.getInt("duracionminutos");
				ruta = new TransferRuta(nombre, estacionOrigen, estacionDestino , duracion, precio);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ruta;
	}


}
