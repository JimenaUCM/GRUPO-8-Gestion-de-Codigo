package integracion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import negocio.TransferBillete;
import negocio.TransferCliente;
import negocio.TransferServicio;
import negocio.TransferTren;
import negocio.TransferUsuario;
import util.Fecha;
import util.Pair;

public class DAOBDImplBillete implements DAOBillete {

	private static final String _QUERY_ALTA = "INSERT INTO  billete (numeroasiento,  fecha , idtren)  VALUES (?,?,?)";
	private static final String _QUERY_BUSCAR_CLIENTE = "SELECT * FROM billete WHERE idcliente = ?";
	private static final String _QUERY_BUSCAR_TREN = "SELECT * FROM billete WHERE idtren = ?";
	private static final String _QUERY_UPDATE = "UPDATE billete SET fecha = ?, valoracion = ?, estadisponible = ? , idcliente = ? WHERE numeroasiento = ? AND idtren = ?";
	private static final String _QUERY_UPDATE_ANIADIR_SUBSCRIPCION = "INSERT INTO servicio-billetes (nombre.servicio, numeroasiento, idtren) VALUES (?, ?, ?)";
	private static final String _QUERY_UPDATE_ELIMINAR_SUBSCRIPCION = "DELETE FROM servicios-billetes WHERE idtren = ? AND numeroasiento = ?";

	static DAOBDImplBillete _daoBillete = null;
	private Connection _connection;
	private DAOTren _daoTren;
	private DAOCliente _daoCliente;
	public static final int _ASIENTOS_TREN = 100;

	DAOBDImplBillete(Connection connection, DAOTren daoTren, DAOCliente daoCliente) {
		_connection = connection;
		_daoTren = daoTren;
		_daoCliente = daoCliente;
	}

	static public DAOBDImplBillete getInstance(Connection connection, DAOTren daoTren, DAOCliente daoCliente) {
		if (_daoBillete == null)
			_daoBillete = new DAOBDImplBillete(connection, daoTren, daoCliente);
		return _daoBillete;
	}

	@Override
	public boolean darAlta(TransferTren tren) {
		int filasAfectadas = 0;
		int j;
		for (j = 1; j <= _ASIENTOS_TREN; j++) {
			try (PreparedStatement st = _connection.prepareStatement(_QUERY_ALTA)) {
				// Dar valores a parametro de busqueda
				st.setInt(1, j);
				st.setString(2, tren.getHoraSalida().getFecha().toString());
				st.setString(3, tren.getId());
				// Ejecuta la query
				filasAfectadas += st.executeUpdate();
			} catch (SQLException e) {
				System.err.print(e.getMessage());
				e.printStackTrace();
				return false;
			}
		}
		return filasAfectadas == j;
	}

	@Override
	public Collection<TransferBillete> BuscarBilleteCliente(String dni) {
		Collection<TransferBillete> billetes = new ArrayList<TransferBillete>();
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BUSCAR_CLIENTE)) {
			// Dar valores a parametro de busqueda
			st.setString(1, dni);
			// Ejecuta la query
			ResultSet rs = st.executeQuery();
			while (rs.next())
				billetes.add(get_nextBillete(rs));
			return new ArrayList<TransferBillete>();
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	public TransferBillete get_nextBillete(ResultSet rs) {
		TransferBillete billete = null;
		try {
			int numeroAsiento = rs.getInt("numeroasiento");
			int valoracion = rs.getInt("valoracion");
			boolean estaDisponible = rs.getBoolean("estaDisponible");
			String idtren = rs.getString("idtren");
			TransferTren tren = _daoTren.buscarId(idtren);
			String idcliente = rs.getString("idcliente");
			TransferCliente cliente = _daoCliente.buscar(idcliente);
			Fecha fecha = Fecha.parseFecha(rs.getString("fecha"));
			billete = new TransferBillete(tren, numeroAsiento, tren.getRuta().getPrecio(), valoracion, estaDisponible, cliente, fecha);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return billete;
	}

	@Override
	public boolean actualizar(TransferBillete billete) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_UPDATE)) {
			// Dar valores a parametro de busqueda
			st.setDate(1, java.sql.Date.valueOf(billete.getFecha().toString()));
			st.setInt(2, billete.getValoracion());
			st.setBoolean(3, billete.isEstaDisponible());
			st.setString(4, billete.getCliente() == null ? "null" : billete.getCliente().getDni());
			st.setInt(5, billete.getNumeroAsiento());
			st.setString(6, billete.getTren().getId());
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			if (billete.getCliente() == null)
				eliminarServicio(billete);
			else
				aniadirServicio(billete.getServicios(), billete);
			return filasAfectadas == 1;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	public boolean aniadirServicio(Collection<TransferServicio> servicios, TransferBillete billete) {
		int filasAfectadas = 0;
		Iterator<TransferServicio> iterator = servicios.iterator();

		while (iterator.hasNext()) {
			try (PreparedStatement st = _connection.prepareStatement(_QUERY_UPDATE_ANIADIR_SUBSCRIPCION)) {
				// Dar valores a parametro de busqueda
				st.setString(1, iterator.next().get_nombre());
				st.setInt(2, billete.getNumeroAsiento());
				st.setString(3, billete.getTren().getId());
				// Ejecuta la query
				filasAfectadas += st.executeUpdate();
			} catch (SQLException e) {
				System.err.print(e.getMessage());
				e.printStackTrace();
				return false;
			}
		}
		return filasAfectadas == servicios.size();
	}

	public boolean eliminarServicio(TransferBillete billete) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_UPDATE_ELIMINAR_SUBSCRIPCION)) {
			// Dar valores a parametro de busqueda
			st.setString(1, billete.getTren().getId());
			st.setInt(2, billete.getNumeroAsiento());
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			return filasAfectadas == 1;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	public TransferServicio get_nextServicio(ResultSet rs) {
		TransferServicio servicio = null;
		try {
			String nombre = rs.getString("nombre");
			int precio = rs.getInt("precio");
			servicio = new TransferServicio(nombre, precio);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return servicio;
	}

	@Override
	public Collection<TransferBillete> BuscarBilleteTren(String idTren) {
		Collection<TransferBillete> billetes = new ArrayList<TransferBillete>();
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BUSCAR_TREN)) {
			// Dar valores a parametro de busqueda
			st.setString(1, idTren);
			// Ejecuta la query
			ResultSet rs = st.executeQuery();
			while (rs.next())
				billetes.add(get_nextBillete(rs));
			return billetes;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
}
