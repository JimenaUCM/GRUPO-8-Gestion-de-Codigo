package integracion;

import java.util.Collection;

import negocio.TipoTren;
import negocio.TransferEstacion;
import negocio.TransferTren;
import util.Fecha;

public interface DAOTren {
	public boolean darAlta(TransferTren tren);

	public int darAlta(Collection<TransferTren> tren);

	public TransferTren buscarId(String id);

	public Collection<TransferTren> buscarViaje(TransferEstacion origen, TransferEstacion destino, TipoTren tipotren,
			Fecha fecha);

	public boolean darBaja(String id);

	public int darBaja(Collection<String> id);

	public boolean actualizar(TransferTren tren);

	public int actualizar(Collection<TransferTren> tren);
}