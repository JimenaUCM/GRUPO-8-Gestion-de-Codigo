package integracion;

import java.sql.Connection;

public class FactoriaDAOBDImp implements FactoriaDAO {

	private Connection connection;

	public FactoriaDAOBDImp() {
		DataBaseConnection DBConnection = new DataBaseConnection();
		connection = DBConnection.getConnection();
	}

	private DAOUsuario getDAOUsuario() {
		return new DAOBDImplUsuario(connection);
	}

	@Override
	public DAOCliente getDAOCliente() {
		return new DAOBDImplCliente(connection, this.getDAOUsuario());
	}

	@Override
	public DAOAdmin getDAOAdmin() {
		return new DAOBDImplAdmin(connection, this.getDAOUsuario());
	}

	@Override
	public DAOBillete getDAOBillete() {
		return new DAOBDImplBillete(connection, this.getDAOTren(), this.getDAOCliente());
	}

	@Override
	public DAOEstacion getDAOEstacion() {
		return new DAOBDImplEstacion(connection);
	}

	@Override
	public DAORuta getDAORuta() {
		return new DAOBDImplRuta(connection, this.getDAOEstacion());
	}

	@Override
	public DAOServicio getDAOServicio() {
		return new DAOBDImplServicio(connection);

	}

	@Override
	public DAOTren getDAOTren() {
		return new DAOBDImplTren(connection, this.getDAORuta());

	}

}
