package integracion;

import java.util.Collection;

import negocio.TransferServicio;

public interface DAOServicio {

	public boolean darAlta(TransferServicio servicio);

	public int darAlta(Collection<TransferServicio> servicios);

	public TransferServicio buscar(String nombre);

	public boolean darBaja(String nombre);

	public int darBaja(Collection<String> nombres);

	public boolean actualizar(TransferServicio servicios);

	public int actualizar(Collection<TransferServicio> servicio);

	public Collection<TransferServicio> buscarListaServicios();
}
