package integracion;

import java.util.Collection;

import negocio.TransferUsuario;

public interface DAOUsuario {

	public boolean darAlta(TransferUsuario usuario);

	public int darAlta(Collection<TransferUsuario> usuarios);

	public TransferUsuario buscar(String dni);

	public boolean darBaja(String dni);

	public int darBaja(Collection<String> dnis);

	public boolean actualizar(TransferUsuario usuario);

	public int actualizar(Collection<TransferUsuario> usuarios);
}