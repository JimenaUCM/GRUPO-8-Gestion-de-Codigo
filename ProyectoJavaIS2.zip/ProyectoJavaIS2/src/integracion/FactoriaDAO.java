package integracion;

public interface FactoriaDAO {
	public DAOCliente getDAOCliente();

	public DAOAdmin getDAOAdmin();

	public DAOBillete getDAOBillete();

	public DAOEstacion getDAOEstacion();

	public DAORuta getDAORuta();

	public DAOServicio getDAOServicio();

	public DAOTren getDAOTren();
}