package integracion;

import java.util.Collection;

import negocio.TransferEstacion;
import util.Pair;

public interface DAOEstacion {

	public boolean darAlta(TransferEstacion estacion);

	public int darAlta(Collection<TransferEstacion> estaciones);

	public TransferEstacion buscar(String nombre, String localidad);

	public boolean darBaja(String nombre, String localidad);

	public int darBaja(Collection<Pair<String, String>> estaciones);

	public Collection<String> buscarNombresEstaciones();

	public Collection<String> buscarLocalidadesEstaciones();
}
