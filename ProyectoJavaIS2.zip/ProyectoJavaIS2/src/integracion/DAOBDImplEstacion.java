package integracion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import negocio.TransferEstacion;
import negocio.TransferServicio;
import util.Pair;

public class DAOBDImplEstacion implements DAOEstacion {

	private static final String _QUERY_BUSCAR = "SELECT * FROM estacion WHERE nombre  = ? AND  localidad = ?";
	private static final String _QUERY_BUSCAR_NOMBRES = "SELECT DISTINCT nombre FROM estacion";
	private static final String _QUERY_BUSCAR_LOCALIDADES = "SELECT DISTINCT localidad FROM estacion";
	private static final String _QUERY_ALTA = "INSERT INTO servicio (nombre, localidad) VALUES (?,?)";
	private static final String _QUERY_BAJA = "DELETE FROM estacion WHERE nombre  = ? AND  localidad = ?";

	private static DAOBDImplEstacion _daoEstacion = null;
	private Connection _connection;

	DAOBDImplEstacion(Connection connection) {
		_connection = connection;
	}

	static public DAOBDImplEstacion getInstance(Connection connection) {
		if (_daoEstacion == null)
			_daoEstacion = new DAOBDImplEstacion(connection);
		return _daoEstacion;
	}

	@Override
	public boolean darAlta(TransferEstacion estacion) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_ALTA)) {
			// Dar valores a parametro de busqueda
			st.setString(1, estacion.getNombre());
			st.setString(2, estacion.getLocalidad());
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			return filasAfectadas == 1;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}

	}

	@Override
	public int darAlta(Collection<TransferEstacion> estaciones) {
		int filasAfectadas = 0;
		for (TransferEstacion estacion : estaciones) {
			if (darAlta(estacion)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;
	}

	@Override
	public TransferEstacion buscar(String nombre, String localidad) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BUSCAR)) {
			// Dar valores a parametro de busqueda
			st.setString(1, nombre);
			st.setString(2, localidad);
			// Ejecuta la query
			ResultSet rs = st.executeQuery();
			return get_nextEstacion(rs);
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean darBaja(String nombre, String localidad) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BAJA)) {
			// Dar valores a parametro de busqueda
			st.setString(1, nombre);
			st.setString(2, localidad);
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			return filasAfectadas == 1;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public int darBaja(Collection<Pair<String, String>> estaciones) {
		int filasAfectadas = 0;
		for (Pair<String,String> estacion : estaciones) {
			if (darBaja(estacion.first, estacion.second)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;
	}

	public TransferEstacion get_nextEstacion(ResultSet rs) {
		TransferEstacion estacion = null;
		try {
			if (rs.next()) {
				String nombre = rs.getString("nombre");
				String localidad = rs.getString("localidad");
				estacion = new TransferEstacion(nombre, localidad);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return estacion;
	}

	@Override
	public Collection<String> buscarNombresEstaciones() {
		Collection<String> estaciones = new ArrayList<String>();
		
		try {
			Statement st = _connection.createStatement();
			ResultSet rs = st.executeQuery(_QUERY_BUSCAR_NOMBRES);
			while (rs.next()) {
				estaciones.add(rs.getString("nombre"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return estaciones;
	}
	
	@Override
	public Collection<String> buscarLocalidadesEstaciones() {
		Collection<String> estaciones = new ArrayList<String>();
		
		try {
			Statement st = _connection.createStatement();
			ResultSet rs = st.executeQuery(_QUERY_BUSCAR_LOCALIDADES);
			while (rs.next()) {
				estaciones.add(rs.getString("localidad"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return estaciones;
	}
}
