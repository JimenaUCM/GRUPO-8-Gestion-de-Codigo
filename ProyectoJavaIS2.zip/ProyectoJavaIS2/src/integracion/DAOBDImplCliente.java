package integracion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import negocio.TransferCliente;
import negocio.TransferUsuario;

public class DAOBDImplCliente implements DAOCliente {

	private static final String _QUERY_BUSCAR = "SELECT * FROM cliente WHERE dni = ?";
	private static final String _QUERY_ALTA = "INSERT INTO cliente (dni, saldo) VALUES (?,0)";
	private static final String _QUERY_BAJA = "DELETE FROM cliente WHERE dni = ?";
	private static final String _QUERY_UPDATE = "UPDATE cliente SET saldo = ? WHERE dni = ?";

	private static DAOBDImplCliente _daoCliente = null;
	private DAOUsuario _daoUsuario;
	private Connection _connection;

	DAOBDImplCliente(Connection connection, DAOUsuario daoUsuario) {
		_connection = connection;
		_daoUsuario = daoUsuario;
	}

	static public DAOBDImplCliente getInstance(Connection connection, DAOUsuario daoUsuario) {
		if (_daoCliente == null) {
			_daoCliente = new DAOBDImplCliente(connection, daoUsuario);
		}
		return _daoCliente;

	}

	@Override
	public boolean darAlta(TransferCliente cliente) {
		if (_daoUsuario.darAlta(cliente)) {
			try (PreparedStatement st = _connection.prepareStatement(_QUERY_ALTA)) {
				// Dar valores a parametro de busqueda
				st.setString(1, cliente.getDni());
				// Ejecuta la query
				if (st.executeUpdate() == 1) {
					return true;
				} else {
					_daoUsuario.darBaja(cliente.getDni());
				}
			} catch (SQLException e) {
				System.err.print(e.getMessage());
				e.printStackTrace();
				_daoUsuario.darBaja(cliente.getDni());
				return false;
			}
		}
		return false;
	}

	@Override
	public int darAlta(Collection<TransferCliente> clientes) {
		int filasAfectadas = 0;
		for (TransferCliente cliente : clientes) {
			if (this.darAlta(cliente)) {
				filasAfectadas++;
			}
		}

		return filasAfectadas;
	}

	@Override
	public TransferCliente buscar(String dni) {

		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BUSCAR)) {
			// Dar valores a parametro de busqueda
			st.setString(1, dni);
			// Ejecuta la query
			ResultSet rs = st.executeQuery();
			if (!rs.next()) {
				return null;
			}
			TransferUsuario usuario = _daoUsuario.buscar(dni);
			int saldo = rs.getInt("saldo");

			return new TransferCliente(usuario, saldo);
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean darBaja(String dni) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BAJA)) {
			// Dar valores a parametro de busqueda
			st.setString(1, dni);
			// Ejecuta la query
			if (st.executeUpdate() != 1) {
				return false;
			}
			return _daoUsuario.darBaja(dni);
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public int darBaja(Collection<String> dnis) {
		int filasAfectadas = 0;
		for (String dni : dnis) {
			if (this.darBaja(dni)) {
				filasAfectadas++;
			}
		}

		return filasAfectadas;
	}

	@Override
	public boolean actualizar(TransferCliente cliente) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_UPDATE)) {
			// Dar valores a parametro de busqueda
			st.setInt(1, cliente.getSaldo());
			st.setString(2, cliente.getDni());
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			if (filasAfectadas != 1) {
				return false;
			}
			return _daoUsuario.actualizar(cliente);
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public int actualizar(Collection<TransferCliente> clientes) {
		int filasAfectadas = 0;
		for (TransferCliente cliente : clientes) {
			if (this.actualizar(cliente)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;
	}

}
