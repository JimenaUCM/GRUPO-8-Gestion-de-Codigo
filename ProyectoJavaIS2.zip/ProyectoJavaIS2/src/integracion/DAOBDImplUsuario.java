package integracion;

import java.sql.*;
import java.util.Collection;

import negocio.TransferUsuario;

public class DAOBDImplUsuario implements DAOUsuario {

	private static final String _QUERY_BUSCAR = "SELECT * FROM usuario WHERE dni = ?";
	private static final String _QUERY_ALTA = "INSERT INTO usuario (nombre, apellidos, dni, contraseña) VALUES (?,?,?,?)";
	private static final String _QUERY_BAJA = "DELETE FROM usuario WHERE dni = ?";
	private static final String _QUERY_UPDATE = "UPDATE usuario SET nombre = ?, apellidos = ?, contraseña = ? WHERE dni = ?";

	static DAOBDImplUsuario _daoUsuario = null;
	private Connection _connection;

	DAOBDImplUsuario(Connection connection) {
		_connection = connection;
	}

	static public DAOBDImplUsuario getInstance(Connection connection) {
		if (_daoUsuario == null) {
			_daoUsuario = new DAOBDImplUsuario(connection);
		}
		return _daoUsuario;
	}

	@Override
	public boolean darAlta(TransferUsuario usuario) {
		if (buscar(usuario.getDni()) != null) {
			throw new IllegalArgumentException("Ya hay un usuario con ese dni registrado");
		}
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_ALTA)) {
			// Dar valores a parametro de busqueda
			st.setString(1, usuario.getNombre());
			st.setString(2, usuario.getApellidos());
			st.setString(3, usuario.getDni());
			st.setString(4, usuario.getPassword());
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			return filasAfectadas == 1;
		} catch (SQLException e) {
			throw new IllegalArgumentException(e.getMessage());
		}
	}

	@Override
	public int darAlta(Collection<TransferUsuario> usuarios) {
		int filasAfectadas = 0;
		for (TransferUsuario usuario : usuarios) {
			if (darAlta(usuario)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;
	}

	@Override
	public TransferUsuario buscar(String dni) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BUSCAR)) {
			// Dar valores a parametro de busqueda
			st.setString(1, dni);
			// Ejecuta la query
			ResultSet rs = st.executeQuery();
			return get_nextUsuario(rs);
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean darBaja(String dni) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BAJA)) {
			// Dar valores a parametro de busqueda
			st.setString(1, dni);
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			return filasAfectadas == 1;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public int darBaja(Collection<String> dnis) {
		int filasAfectadas = 0;
		for (String dni : dnis) {
			if (darBaja(dni)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;
	}

	@Override
	public boolean actualizar(TransferUsuario usuario) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_UPDATE)) {
			// Dar valores a parametro de busqueda
			st.setString(1, usuario.getNombre());
			st.setString(2, usuario.getApellidos());
			st.setString(3, usuario.getPassword());
			st.setString(4, usuario.getDni());
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			return filasAfectadas == 1;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public int actualizar(Collection<TransferUsuario> usuarios) {
		int filasAfectadas = 0;
		for (TransferUsuario usuario : usuarios) {
			if (actualizar(usuario)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;
	}

	public TransferUsuario get_nextUsuario(ResultSet rs) {
		TransferUsuario usuario = null;
		try {
			if (rs.next()) {
				String nombre = rs.getString("nombre");
				String apellidos = rs.getString("apellidos");
				String dni = rs.getString("dni");
				String password = rs.getString("contraseña");
				usuario = new TransferUsuario(nombre, apellidos, dni, password);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return usuario;
	}
}
