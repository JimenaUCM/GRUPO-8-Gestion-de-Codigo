package integracion;

import java.util.Collection;
import negocio.TransferBillete;
import negocio.TransferTren;

public interface DAOBillete {
	public boolean darAlta(TransferTren tren);

	public Collection<TransferBillete> BuscarBilleteCliente(String dni);

	public Collection<TransferBillete> BuscarBilleteTren(String idTren);

	public boolean actualizar(TransferBillete billete);

}
