package integracion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import negocio.TipoTren;
import negocio.TransferCliente;
import negocio.TransferEstacion;
import negocio.TransferRuta;
import negocio.TransferTren;
import negocio.TransferUsuario;
import util.Fecha;
import util.Horario;

public class DAOBDImplTren implements DAOTren {

	private static final String _QUERY_BUSCAR_ID = "SELECT * FROM tren WHERE id = ?";
	private static final String _QUERY_BUSCAR_TIPOTREN = "SELECT * FROM tren WHERE tipotren = ? AND horasalida >= ? AND horasalida < DATE_ADD(?, INTERVAL 1 DAY) AND ruta = (SELECT nombre FROM ruta WHERE estacionorigen = ? AND estaciondestino = ?)";
	private static final String _QUERY_ALTA = "INSERT INTO tren (id , tipotren, horasalida, nombreruta) VALUES (?,?,?,?)";
	private static final String _QUERY_BAJA = "DELETE FROM tren WHERE id = ?";
	private static final String _QUERY_UPDATE = "UPDATE tren SET tipotren = ?, WHERE id = ?";

	private static DAOBDImplTren _daoTren = null;
	private Connection _connection;
	private DAORuta _daoRuta;

	DAOBDImplTren(Connection connection, DAORuta daoRuta) {
		_connection = connection;
		_daoRuta = daoRuta;
	}

	static public DAOBDImplTren getInstance(Connection connection, DAORuta daoRuta) {
		if (_daoTren == null)
			_daoTren = new DAOBDImplTren(connection, daoRuta);
		return _daoTren;
	}

	@Override
	public boolean darAlta(TransferTren tren) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_ALTA)) {
			// Dar valores a parametro de busqueda
			st.setString(1, tren.getId());
			st.setString(2, tren.getTipoTren().name());
			st.setString(3, tren.getHoraSalida().getFecha().toString());
			st.setString(4, tren.getRuta().getNombre());
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			return filasAfectadas == 1;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			//dddd
			return false;
		}

	}

	@Override
	public int darAlta(Collection<TransferTren> tren) {
		int filasAfectadas = 0;
		for (TransferTren t : tren) {
			if (darAlta(t)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;
	}

	@Override
	public boolean darBaja(String id) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BAJA)) {
			// Dar valores a parametro de busqueda
			st.setString(1, id);
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			return filasAfectadas == 1;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public int darBaja(Collection<String> id) {
		int filasAfectadas = 0;
		for (String idTren : id) {
			if (darBaja(idTren)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;
	}

	@Override
	public boolean actualizar(TransferTren tren) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_UPDATE)) {
			// Dar valores a parametro de busqueda
			st.setString(1, tren.getTipoTren().name());
			// Ejecuta la query
			int filasAfectadas = st.executeUpdate();
			if (filasAfectadas != 1) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public int actualizar(Collection<TransferTren> trenes) {
		int filasAfectadas = 0;
		for (TransferTren tren : trenes) {
			if (this.actualizar(tren)) {
				filasAfectadas++;
			}
		}
		return filasAfectadas;
	}

	@Override
	public TransferTren buscarId(String id) {
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BUSCAR_ID)) {
			// Dar valores a parametro de busqueda
			st.setString(1, id);
			// Ejecuta la query
			ResultSet rs = st.executeQuery();
			if (rs.next())
				return get_nextTren(rs);
			return null;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	public TransferTren get_nextTren(ResultSet rs) {
		TransferTren tren = null;
		try {

			String id = rs.getString("id");
			Horario horasalida = Horario.parseHorario(rs.getString("horasalida"));
			TipoTren tipotren = TipoTren.values()[rs.getInt("tipotren")];
			String idruta = rs.getString("ruta");
			TransferRuta ruta = _daoRuta.buscar(idruta);
			tren = new TransferTren(id, horasalida, tipotren, ruta);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return tren;
	}

	@Override
	public Collection<TransferTren> buscarViaje(TransferEstacion origen, TransferEstacion destino, TipoTren tipotren,
			Fecha fecha) {

		Collection<TransferTren> trenes = new ArrayList<TransferTren>();
		try (PreparedStatement st = _connection.prepareStatement(_QUERY_BUSCAR_TIPOTREN)) {
			// Dar valores a parametro de busqueda
			st.setInt(1,  tipotren.ordinal());
			st.setString(2, fecha.toString());
			st.setString(3, fecha.toString());
			st.setString(4, origen.getNombre());
			st.setString(5, destino.getNombre());
			// Ejecuta la query
			ResultSet rs = st.executeQuery();
			while (rs.next())
				trenes.add(get_nextTren(rs));
			return trenes;
		} catch (SQLException e) {
			System.err.print(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

}
