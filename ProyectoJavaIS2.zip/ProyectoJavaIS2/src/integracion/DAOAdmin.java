package integracion;

import java.util.Collection;

import negocio.TransferAdmin;

public interface DAOAdmin {

	public boolean darAlta(TransferAdmin admin);

	public int darAlta(Collection<TransferAdmin> admins);

	public TransferAdmin buscar(String dni);

	public boolean darBaja(String dni);

	public int darBaja(Collection<String> dnis);

	public boolean actualizar(TransferAdmin admin);

	public int actualizar(Collection<TransferAdmin> admins);
}