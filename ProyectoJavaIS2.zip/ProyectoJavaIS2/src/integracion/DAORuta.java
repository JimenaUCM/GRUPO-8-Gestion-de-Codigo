package integracion;

import java.util.Collection;

import negocio.TransferRuta;

public interface DAORuta {

	public boolean darAlta(TransferRuta ruta);

	public int darAlta(Collection<TransferRuta> rutas);

	public TransferRuta buscar(String nombre);

	public boolean darBaja(String nombre);

	public int darBaja(Collection<String> nombres);
}
