package integracion;

import java.sql.*;

public class DataBaseConnection {
	/** Parametros de conexion **/
	private static String bd = "bd-ucmrails";
	private static String login = "root";
	private static String password = "toor";
	private static String url = "jdbc:mysql://localhost/" + bd;
	private Connection connection = null;

	public DataBaseConnection() {
		try {
			// String url = " jdbc : mysql :// hostname / database - name ";
			connection = DriverManager.getConnection(url, login, password);
		} catch (SQLException ex) {
			connection = null;
			ex.printStackTrace();
			System.err.println(" SQLException : " + ex.getMessage());
			System.err.println(" SQLState : " + ex.getSQLState());
			System.err.println(" VendorError : " + ex.getErrorCode());
		}
	}

	public Connection getConnection() {
		return connection;
	}

	public void desconectar() {
		connection = null;
	}
}
